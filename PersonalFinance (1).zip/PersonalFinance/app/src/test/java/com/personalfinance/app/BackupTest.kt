package com.personalfinance.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.personalfinance.app.data.backup.BackupData
import com.personalfinance.app.data.backup.BackupError
import com.personalfinance.app.data.backup.BackupException
import com.personalfinance.app.data.backup.BackupManager
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.db.TransactionEntity
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.TransferDirection
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BackupTest {
    private lateinit var db1: AppDatabase
    private lateinit var db2: AppDatabase
    private lateinit var repo1: FinanceRepository
    private lateinit var repo2: FinanceRepository
    private lateinit var backup1: BackupManager
    private lateinit var backup2: BackupManager
    private val day = LocalDate.of(2025, 3, 15).toEpochDay()

    private fun newDb() = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), AppDatabase::class.java)
        .allowMainThreadQueries().build()

    @Before fun setUp() {
        db1 = newDb(); db2 = newDb()
        repo1 = FinanceRepository(db1); repo2 = FinanceRepository(db2)
        backup1 = BackupManager(db1); backup2 = BackupManager(db2)
        runBlocking { repo1.ensureSystemCategories(); repo2.ensureSystemCategories() }
    }

    @After fun tearDown() { db1.close(); db2.close() }

    private suspend fun fillDb1() {
        val custom = repo1.addCategory(FlowType.EXPENSE, "Спорт")
        val mom = db1.categoryDao().getBySystemKey("mom")!!.id
        val food = db1.categoryDao().getBySystemKey("food")!!.id
        repo1.saveOperation(null, FlowType.INCOME, 100_000, mom, day, "первый")
        repo1.saveOperation(null, FlowType.EXPENSE, 20_000, food, day + 1, null)
        repo1.saveOperation(null, FlowType.EXPENSE, 5_050, custom, day + 2, "зал")
        repo1.saveTransfer(null, TransferDirection.TO_SAVINGS, 30_000, day, "в копилку")
        repo1.saveTransfer(null, TransferDirection.FROM_SAVINGS, 5_000, day + 3, null)
        db1.settingsDao().upsert(com.personalfinance.app.data.db.AppSettingsEntity(1, "tk"))
    }

    private suspend fun snapshot(db: AppDatabase) = listOf(
        db.categoryDao().getAll(), db.transactionDao().getAll(), db.savingsDao().getAll(), db.settingsDao().get()
    )

    // 19
    @Test fun exportThenImport_restoresEverythingWithoutLoss() = runBlocking<Unit> {
        fillDb1()
        val json = backup1.exportJson()
        val data = backup2.parse(json)
        backup2.restore(data)
        assertEquals(snapshot(db1), snapshot(db2))
        assertEquals(repo1.currentTotals(), repo2.currentTotals())
        assertEquals("tk", db2.settingsDao().get()!!.language)
    }

    // 21
    @Test fun repeatedImport_doesNotCreateDuplicates() = runBlocking<Unit> {
        fillDb1()
        val json = backup1.exportJson()
        backup2.restore(backup2.parse(json))
        val first = snapshot(db2)
        backup2.restore(backup2.parse(json))
        backup2.restore(backup2.parse(json))
        assertEquals(first, snapshot(db2))
        assertEquals(3, db2.transactionDao().count())
        assertEquals(2, db2.savingsDao().count())
    }

    @Test fun import_replacesExistingData() = runBlocking<Unit> {
        fillDb1()
        val mom = db2.categoryDao().getBySystemKey("mom")!!.id
        repo2.saveOperation(null, FlowType.INCOME, 999, mom, day, "старое")
        backup2.restore(backup2.parse(backup1.exportJson()))
        assertEquals(3, db2.transactionDao().count())
        assertTrue(db2.transactionDao().getAll().none { it.comment == "старое" })
    }

    @Test fun import_ofEmptyBackup_works() = runBlocking<Unit> {
        backup2.restore(backup2.parse(backup1.exportJson()))
        assertEquals(0, db2.transactionDao().count())
        assertEquals(11, db2.categoryDao().getAll().size)
    }

    private fun mutate(json: String, change: (JSONObject) -> Unit): String {
        val o = JSONObject(json)
        change(o)
        return o.toString()
    }

    private fun expectParseError(expected: BackupError, json: String) {
        try {
            backup2.parse(json)
            fail("Expected $expected")
        } catch (e: BackupException) {
            assertEquals(expected, e.error)
        }
    }

    // 20
    @Test fun corruptedFiles_areRejected_andDatabaseStaysIntact() = runBlocking<Unit> {
        fillDb1()
        val good = backup1.exportJson()
        // в db2 лежат свои данные, которые должны пережить все неудачные импорты
        val mom2 = db2.categoryDao().getBySystemKey("mom")!!.id
        repo2.saveOperation(null, FlowType.INCOME, 777, mom2, day, "моё")
        val before = snapshot(db2)

        fun tx(o: JSONObject, i: Int) = o.getJSONArray("transactions").getJSONObject(i)

        expectParseError(BackupError.CORRUPTED, "")
        expectParseError(BackupError.CORRUPTED, "not json at all")
        expectParseError(BackupError.CORRUPTED, "[]")
        expectParseError(BackupError.CORRUPTED, good.substring(0, good.length / 2)) // обрезанный файл
        expectParseError(BackupError.CORRUPTED, mutate(good) { it.remove("transactions") })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { it.put("format", "Other") })
        expectParseError(BackupError.UNSUPPORTED_VERSION, mutate(good) { it.put("version", 2) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { it.put("language", "xx") })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("amountMinor", 0) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("amountMinor", -10) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("amountMinor", 1.5) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("amountMinor", "100") })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("date", 5) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("categoryId", 99999) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 0).put("type", "EXPENSE") }) // категория дохода
        expectParseError(BackupError.INVALID_DATA, mutate(good) { tx(it, 1).put("id", tx(it, 0).getLong("id")) })
        expectParseError(BackupError.INVALID_DATA, mutate(good) {
            it.getJSONArray("categories").getJSONObject(0).put("systemKey", "unknown_key")
        })
        // суммы по отдельности корректны, но итоговый баланс отрицательный
        expectParseError(BackupError.INCONSISTENT, mutate(good) { tx(it, 1).put("amountMinor", 99_999_999) })

        assertEquals(before, snapshot(db2))
    }

    @Test fun failedRestore_rollsBackAndKeepsCurrentData() = runBlocking<Unit> {
        fillDb1()
        val mom2 = db2.categoryDao().getBySystemKey("mom")!!.id
        repo2.saveOperation(null, FlowType.INCOME, 777, mom2, day, "моё")
        val before = snapshot(db2)

        val good = backup2.parse(backup1.exportJson())
        val dup: TransactionEntity = good.transactions[0]
        // в обход проверки parse() подсовываем данные, которые БД отвергнет посреди восстановления
        val broken = BackupData(good.categories, good.transactions + dup, good.transfers, good.language)
        try {
            backup2.restore(broken)
            fail("restore must fail")
        } catch (e: BackupException) {
            assertEquals(BackupError.RESTORE_FAILED, e.error)
        }
        assertEquals(before, snapshot(db2))
    }
}
