package com.personalfinance.app

import android.content.res.Resources
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Проверяет полноту локализации на уровне ресурсов (все строки интерфейса определены для обоих языков).
 * Визуальную проверку экранов этот тест не заменяет — см. отчёт.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class LocalizationTest {
    private fun parse(path: String): Map<String, String> {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(File(path))
        val nodes = doc.getElementsByTagName("string")
        return (0 until nodes.length).associate { nodes.item(it).attributes.getNamedItem("name").nodeValue to nodes.item(it).textContent }
    }

    private val placeholder = Regex("%\\d\\$[sd]")

    @Test fun russianAndTurkmenFiles_haveSameKeysAndPlaceholders() {
        val ru = parse("src/main/res/values/strings.xml")
        val tk = parse("src/main/res/values-tk/strings.xml")
        assertEquals(ru.keys, tk.keys)
        ru.forEach { (key, ruValue) ->
            val tkValue = tk.getValue(key)
            assertTrue("empty tk string: $key", tkValue.isNotBlank())
            assertEquals("placeholders differ in $key",
                placeholder.findAll(ruValue).map { it.value }.sorted().toList(),
                placeholder.findAll(tkValue).map { it.value }.sorted().toList())
        }
    }

    // 17
    @Test fun russianLocale_allStringsResolve() {
        val res = ApplicationProvider.getApplicationContext<android.content.Context>().resources
        checkAllStrings(res)
        assertEquals("Главная", res.getString(R.string.tab_home))
        assertEquals("Продукты", res.getString(R.string.cat_groceries))
    }

    // 18
    @Test @Config(sdk = [34], qualifiers = "tk")
    fun turkmenLocale_allStringsResolve_andDifferFromRussian() {
        val res = ApplicationProvider.getApplicationContext<android.content.Context>().resources
        checkAllStrings(res)
        assertEquals("Baş sahypa", res.getString(R.string.tab_home))
        assertEquals("Azyk önümleri", res.getString(R.string.cat_groceries))
        assertNotEquals("Главная", res.getString(R.string.tab_home))
        assertEquals(12, res.getStringArray(R.array.months).size)
        assertEquals("Ýanwar", res.getStringArray(R.array.months)[0])
    }

    private fun checkAllStrings(res: Resources) {
        val fields = R.string::class.java.fields.filter { it.type == Int::class.javaPrimitiveType }
        assertTrue(fields.size > 100)
        fields.forEach { f ->
            val text = res.getString(f.getInt(null))
            assertFalse("blank: ${f.name}", text.isBlank())
        }
        assertEquals(12, res.getStringArray(R.array.months).size)
    }
}
