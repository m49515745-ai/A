package com.personalfinance.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.DateRange
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.PeriodMode
import com.personalfinance.app.domain.Periods
import com.personalfinance.app.domain.StatsCalculator
import com.personalfinance.app.domain.TransferDirection
import com.personalfinance.app.domain.TxFilter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

/** Суммы везде в тенге: 100 TMT = 10_000. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FinanceRepositoryTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: FinanceRepository
    private val day = LocalDate.of(2025, 3, 15).toEpochDay()

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), AppDatabase::class.java)
            .allowMainThreadQueries().build()
        repo = FinanceRepository(db)
        runBlocking { repo.ensureSystemCategories() }
    }

    @After fun tearDown() { db.close() }

    private suspend fun cat(key: String) = db.categoryDao().getBySystemKey(key)!!.id
    private suspend fun income(amount: Long, key: String = "mom", date: Long = day) =
        repo.saveOperation(null, FlowType.INCOME, amount, cat(key), date, null)
    private suspend fun expense(amount: Long, key: String = "food", date: Long = day) =
        repo.saveOperation(null, FlowType.EXPENSE, amount, cat(key), date, null)
    private suspend fun totals() = repo.totals.first()

    private suspend fun expectError(expected: FinanceError, block: suspend () -> Unit) {
        try {
            block()
            fail("Expected FinanceException($expected)")
        } catch (e: FinanceException) {
            assertEquals(expected, e.error)
        }
    }

    // 1
    @Test fun emptyDatabase_startsAtZero() = runBlocking<Unit> {
        val t = totals()
        assertEquals(0, t.available); assertEquals(0, t.savings); assertEquals(0, t.total)
        assertEquals(0, t.income); assertEquals(0, t.expense)
    }

    // 24
    @Test fun emptyDatabase_allQueriesWorkWithoutErrors() = runBlocking<Unit> {
        assertTrue(repo.operations(TxFilter()).first().isEmpty())
        assertTrue(repo.transfers.first().isEmpty())
        val ops = repo.operationsInRange(0, Long.MAX_VALUE / 2).first()
        val s = StatsCalculator.summary(ops)
        assertEquals(0, s.income); assertEquals(0, s.expense)
        assertTrue(StatsCalculator.categorySlices(ops, FlowType.EXPENSE).isEmpty())
        assertEquals(31, StatsCalculator.buckets(ops, DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31)), false).size)
        assertEquals(11, repo.categories.first().size) // 3 дохода + 8 расходов
    }

    // 2
    @Test fun income_increasesBalance() = runBlocking<Unit> {
        income(100_000)
        assertEquals(100_000, totals().available)
    }

    // 3
    @Test fun expense_decreasesBalance() = runBlocking<Unit> {
        income(100_000); expense(25_050)
        assertEquals(74_950, totals().available)
    }

    // 4
    @Test fun expense_beyondBalance_isRejectedAndNothingSaved() = runBlocking<Unit> {
        income(10_000)
        expectError(FinanceError.INSUFFICIENT_BALANCE) { expense(10_001) }
        assertEquals(1, db.transactionDao().count())
        assertEquals(10_000, totals().available)
    }

    // 5
    @Test fun transferToSavings_keepsTotalMoney() = runBlocking<Unit> {
        income(100_000)
        val before = totals().total
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 30_000, day, null)
        val t = totals()
        assertEquals(before, t.total)
        assertEquals(70_000, t.available)
        assertEquals(30_000, t.savings)
        assertEquals(100_000, t.income) // переводы не влияют на доходы и расходы
        assertEquals(0, t.expense)
    }

    // 6
    @Test fun returnFromSavings_isNotIncome() = runBlocking<Unit> {
        income(100_000)
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 30_000, day, null)
        repo.saveTransfer(null, TransferDirection.FROM_SAVINGS, 10_000, day, null)
        val t = totals()
        assertEquals(100_000, t.income)
        assertEquals(80_000, t.available)
        assertEquals(20_000, t.savings)
        assertEquals(100_000, t.total)
        val summary = StatsCalculator.summary(repo.operationsInRange(day, day).first())
        assertEquals(100_000, summary.income)
        assertEquals(0, summary.expense)
    }

    // 7
    @Test fun transfer_moreThanAvailable_isRejected() = runBlocking<Unit> {
        income(50_000)
        expectError(FinanceError.INSUFFICIENT_BALANCE) {
            repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 50_001, day, null)
        }
        assertTrue(repo.transfers.first().isEmpty())
    }

    // 8
    @Test fun withdraw_moreThanSavings_isRejected() = runBlocking<Unit> {
        income(50_000)
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 20_000, day, null)
        expectError(FinanceError.INSUFFICIENT_SAVINGS) {
            repo.saveTransfer(null, TransferDirection.FROM_SAVINGS, 20_001, day, null)
        }
        assertEquals(1, repo.transfers.first().size)
        assertEquals(20_000, totals().savings)
    }

    // пример из ТЗ целиком
    @Test fun specExample_endToEnd() = runBlocking<Unit> {
        income(100_000, "mom")
        expense(20_000, "food")
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 30_000, day, null)
        expense(10_000, "taxi")
        val t = totals()
        assertEquals(40_000, t.available)
        assertEquals(30_000, t.savings)
        assertEquals(70_000, t.total)
        assertEquals(100_000, t.income)
        assertEquals(30_000, t.expense)
    }

    // 9
    @Test fun editOperation_recalculatesBalance() = runBlocking<Unit> {
        income(100_000)
        val id = expense(20_000)
        repo.saveOperation(id, FlowType.EXPENSE, 35_000, cat("taxi"), day, "поездка")
        assertEquals(65_000, totals().available)
        val saved = repo.getOperation(id)!!
        assertEquals(cat("taxi"), saved.categoryId)
        assertEquals("поездка", saved.comment)
        assertTrue(saved.updatedAt >= saved.createdAt)
    }

    @Test fun editOperation_thatBreaksBalance_isRejectedAndKeepsOldValue() = runBlocking<Unit> {
        val incomeId = income(100_000)
        expense(80_000)
        expectError(FinanceError.INSUFFICIENT_BALANCE) {
            repo.saveOperation(incomeId, FlowType.INCOME, 50_000, cat("mom"), day, null)
        }
        assertEquals(100_000, repo.getOperation(incomeId)!!.amountMinor)
        assertEquals(20_000, totals().available)
    }

    // 10
    @Test fun deleteOperation_recalculatesBalance() = runBlocking<Unit> {
        income(100_000)
        val e = expense(40_000)
        repo.deleteOperation(e)
        assertEquals(100_000, totals().available)
        assertEquals(1, db.transactionDao().count())
    }

    @Test fun deleteIncome_thatBreaksBalance_isRejected() = runBlocking<Unit> {
        val i = income(100_000)
        expense(80_000)
        expectError(FinanceError.INSUFFICIENT_BALANCE) { repo.deleteOperation(i) }
        assertEquals(2, db.transactionDao().count())
    }

    @Test fun editAndDeleteTransfers_areValidated() = runBlocking<Unit> {
        income(100_000)
        val toId = repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 60_000, day, null)
        repo.saveTransfer(null, TransferDirection.FROM_SAVINGS, 50_000, day, null)
        // уменьшение перевода «в сбережения» сделало бы сбережения отрицательными
        expectError(FinanceError.INSUFFICIENT_SAVINGS) {
            repo.saveTransfer(toId, TransferDirection.TO_SAVINGS, 10_000, day, null)
        }
        expectError(FinanceError.INSUFFICIENT_SAVINGS) { repo.deleteTransfer(toId) }
        assertEquals(10_000, totals().savings)
        // допустимое изменение проходит
        repo.saveTransfer(toId, TransferDirection.TO_SAVINGS, 70_000, day, null)
        assertEquals(20_000, totals().savings)
        assertEquals(100_000, totals().total)
    }

    @Test fun invalidInput_isRejected() = runBlocking<Unit> {
        income(100_000)
        expectError(FinanceError.INVALID_AMOUNT) { expense(0) }
        expectError(FinanceError.INVALID_AMOUNT) { expense(-5) }
        expectError(FinanceError.INVALID_DATE) { expense(100, date = 0) }
        expectError(FinanceError.CATEGORY_MISMATCH) {
            repo.saveOperation(null, FlowType.EXPENSE, 100, cat("mom"), day, null)
        }
        expectError(FinanceError.CATEGORY_NOT_FOUND) {
            repo.saveOperation(null, FlowType.EXPENSE, 100, 9999, day, null)
        }
        expectError(FinanceError.NOT_FOUND) { repo.deleteOperation(9999) }
        assertEquals(1, db.transactionDao().count())
    }

    // 11
    @Test fun changingDate_movesOperationBetweenPeriods() = runBlocking<Unit> {
        val march = LocalDate.of(2025, 3, 20).toEpochDay()
        val april = LocalDate.of(2025, 4, 2).toEpochDay()
        income(100_000, date = march)
        val e = expense(30_000, date = march)
        fun range(m: Int) = Periods.range(PeriodMode.MONTH, LocalDate.of(2025, m, 1), LocalDate.now(), LocalDate.now())
        suspend fun summary(m: Int) = StatsCalculator.summary(repo.operationsInRange(range(m).fromDay, range(m).toDay).first())

        assertEquals(30_000, summary(3).expense)
        assertEquals(0, summary(4).expense)
        repo.saveOperation(e, FlowType.EXPENSE, 30_000, cat("food"), april, null)
        assertEquals(0, summary(3).expense)
        assertEquals(30_000, summary(4).expense)
        assertEquals(70_000, totals().available) // общий баланс не изменился
    }

    // 12
    @Test fun filters_returnCorrectOperations_newestFirst() = runBlocking<Unit> {
        val d1 = LocalDate.of(2025, 3, 1).toEpochDay()
        val d2 = LocalDate.of(2025, 3, 10).toEpochDay()
        val d3 = LocalDate.of(2025, 3, 20).toEpochDay()
        income(1_000_000, "mom", d1)
        expense(1_000, "food", d2)
        expense(2_000, "taxi", d3)
        income(5_000, "clothes", d3)

        val all = repo.operations(TxFilter()).first()
        assertEquals(4, all.size)
        assertEquals(all.map { it.date }.sortedDescending(), all.map { it.date })

        assertEquals(2, repo.operations(TxFilter(type = FlowType.INCOME)).first().size)
        assertEquals(2, repo.operations(TxFilter(type = FlowType.EXPENSE)).first().size)
        assertEquals(1, repo.operations(TxFilter(categoryId = cat("taxi"))).first().size)
        assertEquals(3, repo.operations(TxFilter(fromDay = d2)).first().size)
        assertEquals(2, repo.operations(TxFilter(toDay = d2)).first().size)
        val combined = repo.operations(TxFilter(type = FlowType.EXPENSE, fromDay = d2, toDay = d2)).first()
        assertEquals(1, combined.size)
        assertEquals(1_000, combined[0].amountMinor)
        assertTrue(repo.operations(TxFilter(type = FlowType.INCOME, categoryId = cat("food"))).first().isEmpty())
    }

    // 13
    @Test fun categoryTotals_matchSourceOperations() = runBlocking<Unit> {
        income(1_000_000)
        expense(1_050, "food"); expense(2_025, "food"); expense(700, "taxi")
        val ops = repo.operationsInRange(day, day).first()
        val slices = StatsCalculator.categorySlices(ops, FlowType.EXPENSE)
        assertEquals(2, slices.size)
        assertEquals(cat("food"), slices[0].categoryId)
        assertEquals(3_075, slices[0].amount); assertEquals(2, slices[0].count)
        assertEquals(700, slices[1].amount); assertEquals(1, slices[1].count)
        assertEquals(StatsCalculator.summary(ops).expense, slices.sumOf { it.amount })
        assertEquals(1, StatsCalculator.categorySlices(ops, FlowType.INCOME).size)
    }

    // 14
    @Test fun monthAndYearBoundaries() = runBlocking<Unit> {
        val dec31 = LocalDate.of(2024, 12, 31).toEpochDay()
        val jan1 = LocalDate.of(2025, 1, 1).toEpochDay()
        val jan31 = LocalDate.of(2025, 1, 31).toEpochDay()
        val feb1 = LocalDate.of(2025, 2, 1).toEpochDay()
        listOf(dec31, jan1, jan31, feb1).forEach { income(1_000, date = it) }

        val jan = Periods.range(PeriodMode.MONTH, LocalDate.of(2025, 1, 15), LocalDate.now(), LocalDate.now())
        assertEquals(2, repo.operationsInRange(jan.fromDay, jan.toDay).first().size)
        val y2025 = Periods.range(PeriodMode.YEAR, LocalDate.of(2025, 7, 1), LocalDate.now(), LocalDate.now())
        assertEquals(3, repo.operationsInRange(y2025.fromDay, y2025.toDay).first().size)
        val y2024 = Periods.range(PeriodMode.YEAR, LocalDate.of(2024, 7, 1), LocalDate.now(), LocalDate.now())
        assertEquals(1, repo.operationsInRange(y2024.fromDay, y2024.toDay).first().size)
        // 29 февраля високосного года
        val leapDay = LocalDate.of(2024, 2, 29).toEpochDay()
        income(500, date = leapDay)
        val feb2024 = Periods.range(PeriodMode.MONTH, LocalDate.of(2024, 2, 1), LocalDate.now(), LocalDate.now())
        assertEquals(1, repo.operationsInRange(feb2024.fromDay, feb2024.toDay).first().size)
    }

    // 22
    @Test fun categories_renameKeepsHistory_deleteRules() = runBlocking<Unit> {
        val custom = repo.addCategory(FlowType.EXPENSE, "  Спорт ")
        income(100_000)
        val opId = repo.saveOperation(null, FlowType.EXPENSE, 1_000, custom, day, null)

        repo.renameCategory(custom, "Фитнес")
        val entity = db.categoryDao().getById(custom)!!
        assertEquals("Фитнес", entity.customName)
        assertEquals(custom, repo.getOperation(opId)!!.categoryId) // история не нарушена

        expectError(FinanceError.CATEGORY_IN_USE) { repo.deleteCategory(custom) }
        expectError(FinanceError.CATEGORY_PROTECTED) { repo.deleteCategory(cat("food")) }
        expectError(FinanceError.CATEGORY_PROTECTED) { repo.renameCategory(cat("food"), "X") }
        expectError(FinanceError.EMPTY_NAME) { repo.addCategory(FlowType.EXPENSE, "   ") }
        expectError(FinanceError.NAME_EXISTS) { repo.addCategory(FlowType.EXPENSE, "фитнес") }

        repo.deleteOperation(opId)
        repo.deleteCategory(custom)
        assertTrue(db.categoryDao().getById(custom) == null)
    }

    @Test fun systemCategories_areCreatedOnceOnly() = runBlocking<Unit> {
        repo.ensureSystemCategories(); repo.ensureSystemCategories()
        val cats = repo.categories.first()
        assertEquals(11, cats.size)
        assertEquals(11, cats.mapNotNull { it.systemKey }.toSet().size)
        assertNotNull(cats.firstOrNull { it.systemKey == "mom" })
    }
}
