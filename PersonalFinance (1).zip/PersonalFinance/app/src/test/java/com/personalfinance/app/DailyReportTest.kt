package com.personalfinance.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.TransferDirection
import com.personalfinance.app.domain.TxFilter
import com.personalfinance.app.notify.DailyReportBuilder
import com.personalfinance.app.notify.DailyReportTime
import com.personalfinance.app.notify.NotifyPrefs
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** Ежедневный отчёт (00:00) и список операций по категории. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DailyReportTest {
    private val zone = ZoneId.of("Asia/Ashgabat")
    private fun at(y: Int, m: Int, d: Int, h: Int, min: Int, s: Int = 0) = ZonedDateTime.of(y, m, d, h, min, s, 0, zone)

    // ---------- время срабатывания ----------

    @Test fun nextMidnight_fromEvening_isNextDayStart() {
        val next = DailyReportTime.nextMidnight(at(2026, 11, 8, 23, 59, 59))
        assertEquals(at(2026, 11, 9, 0, 0), next)
    }

    @Test fun nextMidnight_atExactMidnight_isFollowingDay() {
        assertEquals(at(2026, 11, 10, 0, 0), DailyReportTime.nextMidnight(at(2026, 11, 9, 0, 0)))
    }

    @Test fun nextMidnight_crossesMonthAndYear() {
        assertEquals(at(2027, 1, 1, 0, 0), DailyReportTime.nextMidnight(at(2026, 12, 31, 18, 0)))
        assertEquals(at(2024, 2, 29, 0, 0), DailyReportTime.nextMidnight(at(2024, 2, 28, 12, 0)))
    }

    @Test fun nightFrom08To09_reportsDay08() {
        // Сигнал в 00:00 09.11.2026 отчитывается за 08.11.2026.
        val target = LocalDate.of(2026, 11, 9).toEpochDay()
        assertEquals(LocalDate.of(2026, 11, 8).toEpochDay(), DailyReportTime.reportDayFor(target))
        val newYear = LocalDate.of(2027, 1, 1).toEpochDay()
        assertEquals(LocalDate.of(2026, 12, 31).toEpochDay(), DailyReportTime.reportDayFor(newYear))
    }

    @Test fun baseAfterFire_neverSchedulesTheSameMidnightTwice() {
        val target = LocalDate.of(2026, 11, 9).toEpochDay()
        // сигнал пришёл на секунду раньше полуночи
        val early = DailyReportTime.baseAfterFire(at(2026, 11, 8, 23, 59, 59), target)
        assertEquals(at(2026, 11, 10, 0, 0), DailyReportTime.nextMidnight(early))
        // сигнал пришёл с опозданием
        val late = DailyReportTime.baseAfterFire(at(2026, 11, 9, 0, 7), target)
        assertEquals(at(2026, 11, 10, 0, 0), DailyReportTime.nextMidnight(late))
    }

    // ---------- содержание отчёта ----------

    private fun op(id: Long, type: FlowType, amount: Long, cat: Long, day: Long) =
        Operation(id, type, amount, cat, day, null, 0, 0)

    @Test fun builder_countsOnlyExpensesOfThatDay() {
        val d = LocalDate.of(2026, 11, 8).toEpochDay()
        val ops = listOf(
            op(1, FlowType.EXPENSE, 1_000, 1, d),
            op(2, FlowType.EXPENSE, 2_550, 2, d),
            op(3, FlowType.EXPENSE, 500, 1, d),
            op(4, FlowType.INCOME, 100_000, 3, d),         // доход не считается
            op(5, FlowType.EXPENSE, 9_999, 1, d - 1),      // другой день
            op(6, FlowType.EXPENSE, 9_999, 1, d + 1)
        )
        val r = DailyReportBuilder.build(d, ops)
        assertEquals(4_050, r.total)
        assertEquals(3, r.count)
        assertEquals(2, r.top.size)
        assertEquals(2L, r.top[0].categoryId) // 2550 — больше всех
        assertEquals(1_500, r.top[1].amount)
    }

    @Test fun builder_emptyDay_isZero() {
        val r = DailyReportBuilder.build(100, emptyList())
        assertEquals(0, r.total); assertEquals(0, r.count); assertTrue(r.top.isEmpty())
    }

    @Test fun builder_keepsOnlyTopThreeCategories() {
        val d = 500L
        val ops = (1L..5L).map { op(it, FlowType.EXPENSE, it * 100, it, d) }
        val r = DailyReportBuilder.build(d, ops)
        assertEquals(listOf(5L, 4L, 3L), r.top.map { it.categoryId })
        assertEquals(1_500, r.total)
    }

    // ---------- с настоящей базой ----------

    private lateinit var db: AppDatabase
    private lateinit var repo: FinanceRepository

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), AppDatabase::class.java)
            .allowMainThreadQueries().build()
        repo = FinanceRepository(db)
        runBlocking { repo.ensureSystemCategories() }
    }

    @After fun tearDown() { db.close() }

    private suspend fun cat(key: String) = db.categoryDao().getBySystemKey(key)!!.id

    @Test fun reportFromDatabase_ignoresIncomeTransfersAndOtherDays() = runBlocking<Unit> {
        val d8 = LocalDate.of(2026, 11, 8).toEpochDay()
        repo.saveOperation(null, FlowType.INCOME, 1_000_000, cat("mom"), d8, null)
        repo.saveOperation(null, FlowType.EXPENSE, 20_000, cat("food"), d8, null)
        repo.saveOperation(null, FlowType.EXPENSE, 10_000, cat("taxi"), d8, null)
        repo.saveOperation(null, FlowType.EXPENSE, 77_000, cat("food"), d8 + 1, null)
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 300_000, d8, null)

        val ops = repo.operationsInRange(d8, d8).first()
        val r = DailyReportBuilder.build(d8, ops)
        assertEquals(30_000, r.total)
        assertEquals(2, r.count)
    }

    @Test fun reportUsesOperationDate_notEntryTime() = runBlocking<Unit> {
        // Расход, внесённый сегодня, но с датой 08.11, попадает в отчёт за 08.11.
        val d8 = LocalDate.of(2026, 11, 8).toEpochDay()
        repo.saveOperation(null, FlowType.INCOME, 100_000, cat("mom"), d8, null)
        repo.saveOperation(null, FlowType.EXPENSE, 5_000, cat("food"), d8, "позже внёс")
        val r = DailyReportBuilder.build(d8, repo.operationsInRange(d8, d8).first())
        assertEquals(5_000, r.total)
    }

    // ---------- операции категории по датам ----------

    @Test fun categoryDrillDown_listsDatesNewestFirst_andMatchesChartTotal() = runBlocking<Unit> {
        val oct1 = LocalDate.of(2026, 10, 1).toEpochDay()
        val oct31 = LocalDate.of(2026, 10, 31).toEpochDay()
        val debts = cat("debts")
        repo.saveOperation(null, FlowType.INCOME, 10_000_000, cat("mom"), oct1, null)
        val a = repo.saveOperation(null, FlowType.EXPENSE, 100_000, debts, LocalDate.of(2026, 10, 5).toEpochDay(), "Ахмед")
        val b = repo.saveOperation(null, FlowType.EXPENSE, 50_000, debts, LocalDate.of(2026, 10, 20).toEpochDay(), null)
        repo.saveOperation(null, FlowType.EXPENSE, 7_000, cat("food"), LocalDate.of(2026, 10, 10).toEpochDay(), null)
        repo.saveOperation(null, FlowType.EXPENSE, 90_000, debts, LocalDate.of(2026, 11, 2).toEpochDay(), null) // вне периода

        val list = repo.operations(TxFilter(FlowType.EXPENSE, debts, oct1, oct31)).first()
        assertEquals(listOf(b, a), list.map { it.id })            // сначала новые
        assertEquals(LocalDate.of(2026, 10, 20).toEpochDay(), list[0].date)
        assertEquals("Ахмед", list[1].comment)

        // сумма на экране категории = сумма сектора диаграммы за тот же период
        val inPeriod = repo.operationsInRange(oct1, oct31).first()
        val slice = com.personalfinance.app.domain.StatsCalculator
            .categorySlices(inPeriod, FlowType.EXPENSE).first { it.categoryId == debts }
        assertEquals(list.sumOf { it.amountMinor }, slice.amount)
        assertEquals(list.size, slice.count)
    }

    // ---------- настройки уведомлений ----------

    @Test fun notifyPrefs_defaultsAndPersistence() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        val p = NotifyPrefs(ctx)
        assertFalse(p.initialized); assertFalse(p.enabled); assertEquals(-1L, p.lastReportedDay)
        p.initialized = true; p.enabled = true; p.lastReportedDay = 20_000L
        val again = NotifyPrefs(ctx)
        assertTrue(again.initialized); assertTrue(again.enabled); assertEquals(20_000L, again.lastReportedDay)
    }
}
