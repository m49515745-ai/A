package com.personalfinance.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.ui.operations.EditorViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class EditorViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var db: AppDatabase
    private lateinit var repo: FinanceRepository
    private val day = LocalDate.of(2025, 3, 15).toEpochDay()

    @Before fun setUp() {
        Dispatchers.setMain(dispatcher)
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), AppDatabase::class.java)
            .allowMainThreadQueries().build()
        repo = FinanceRepository(db)
        runBlocking { repo.ensureSystemCategories() }
    }

    @After fun tearDown() {
        Dispatchers.resetMain()
        db.close()
    }

    private fun waitUntil(condition: () -> Boolean) {
        repeat(400) {
            if (condition()) return
            dispatcher.scheduler.advanceUntilIdle()
            Thread.sleep(25)
        }
        throw AssertionError("condition not reached in time")
    }

    // 23
    @Test fun rapidRepeatedTaps_createOnlyOneOperation() = runBlocking<Unit> {
        val mom = db.categoryDao().getBySystemKey("mom")!!.id
        repo.saveOperation(null, FlowType.INCOME, 100_000, mom, day, null)

        val vm = EditorViewModel(repo, FlowType.EXPENSE, 0)
        vm.amount = "10"
        repeat(5) { vm.save() } // пять быстрых нажатий подряд
        waitUntil { vm.done }
        vm.save() // и ещё одно после завершения
        dispatcher.scheduler.advanceUntilIdle()
        Thread.sleep(100)

        assertEquals(2, db.transactionDao().count())
        assertEquals(99_000, repo.currentTotals().available)
    }

    @Test fun invalidAmount_isNotSaved_andCanBeCorrected() = runBlocking<Unit> {
        val vm = EditorViewModel(repo, FlowType.INCOME, 0)
        vm.amount = "abc"
        vm.save()
        assertTrue(vm.amountInvalid)
        assertEquals(0, db.transactionDao().count())

        vm.amount = "5.50"
        vm.save()
        waitUntil { vm.done }
        assertEquals(550, db.transactionDao().getAll().single().amountMinor)
    }

    @Test fun rejectedSave_showsErrorAndAllowsRetry() = runBlocking<Unit> {
        val vm = EditorViewModel(repo, FlowType.EXPENSE, 0)
        vm.amount = "10"
        vm.save()
        waitUntil { vm.error != null }
        assertEquals(FinanceError.INSUFFICIENT_BALANCE, vm.error)
        assertFalse(vm.done)
        assertEquals(0, db.transactionDao().count())
    }
}
