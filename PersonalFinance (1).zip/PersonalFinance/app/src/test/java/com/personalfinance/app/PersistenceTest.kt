package com.personalfinance.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.data.repo.SettingsRepository
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.TransferDirection
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate

/** «Перезапуск приложения» = закрыть базу и открыть тот же файл заново. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PersistenceTest {
    private val context: Context get() = ApplicationProvider.getApplicationContext()
    private fun open(name: String) =
        Room.databaseBuilder(context, AppDatabase::class.java, name).allowMainThreadQueries().build()

    // 15
    @Test fun financialData_survivesRestart() = runBlocking<Unit> {
        val name = "persist-finance.db"
        context.deleteDatabase(name)
        val day = LocalDate.of(2025, 3, 15).toEpochDay()

        var db = open(name)
        var repo = FinanceRepository(db)
        repo.ensureSystemCategories()
        val mom = db.categoryDao().getBySystemKey("mom")!!.id
        val food = db.categoryDao().getBySystemKey("food")!!.id
        repo.saveOperation(null, FlowType.INCOME, 100_000, mom, day, "x")
        repo.saveOperation(null, FlowType.EXPENSE, 20_000, food, day, null)
        repo.saveTransfer(null, TransferDirection.TO_SAVINGS, 30_000, day, null)
        db.close()

        db = open(name)
        repo = FinanceRepository(db)
        repo.ensureSystemCategories() // повторный запуск не дублирует категории
        val t = repo.totals.first()
        assertEquals(50_000, t.available)
        assertEquals(30_000, t.savings)
        assertEquals(2, db.transactionDao().count())
        assertEquals(11, repo.categories.first().size)
        db.close()
        context.deleteDatabase(name)
    }

    // 16
    @Test fun selectedLanguage_survivesRestart() = runBlocking<Unit> {
        val name = "persist-settings.db"
        context.deleteDatabase(name)

        var db = open(name)
        assertEquals("ru", SettingsRepository(db).getLanguage()) // значение по умолчанию
        SettingsRepository(db).setLanguage("tk")
        db.close()

        db = open(name)
        assertEquals("tk", SettingsRepository(db).getLanguage())
        assertEquals("tk", SettingsRepository(db).language.first())
        db.close()
        context.deleteDatabase(name)
    }
}
