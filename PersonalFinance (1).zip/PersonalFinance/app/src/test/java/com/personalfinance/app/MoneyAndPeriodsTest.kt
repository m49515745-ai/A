package com.personalfinance.app

import com.personalfinance.app.domain.DateRange
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceTotals
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.PeriodMode
import com.personalfinance.app.domain.Periods
import com.personalfinance.app.domain.StatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class MoneyAndPeriodsTest {
    @Test fun parse_acceptsValidAmounts() {
        assertEquals(1200L, Money.parse("12"))
        assertEquals(1250L, Money.parse("12,5"))
        assertEquals(1250L, Money.parse("12.50"))
        assertEquals(1L, Money.parse("0.01"))
        assertEquals(100000L, Money.parse("1 000"))
    }

    @Test fun parse_rejectsInvalidAmounts() {
        listOf("", " ", "0", "0.00", "-5", "1.234", "abc", "1..2", "1e5", "9999999999").forEach {
            assertNull("must reject '$it'", Money.parse(it))
        }
    }

    @Test fun format_usesExactIntegerArithmetic() {
        assertEquals("0", Money.format(0))
        assertEquals("1\u00A0234.56", Money.format(123456))
        assertEquals("1\u00A0000", Money.format(100000))
        assertEquals("0.05", Money.format(5))
        assertEquals("12.50", Money.format(1250))
        assertEquals("12.50", Money.toInput(1250))
        assertEquals("12", Money.toInput(1200))
    }

    @Test fun totals_formulaFromSpecExample() {
        // доход 1000, расход 200, перевод 300, расход 100 (в тенге)
        val t = FinanceTotals(income = 100_000, expense = 30_000, toSavings = 30_000, fromSavings = 0)
        assertEquals(40_000, t.available)
        assertEquals(30_000, t.savings)
        assertEquals(70_000, t.total)
        assertNull(t.error())
    }

    @Test fun totals_detectInvalidStates() {
        assertEquals(FinanceError.INSUFFICIENT_BALANCE, FinanceTotals(100, 200, 0, 0).error())
        assertEquals(FinanceError.INSUFFICIENT_SAVINGS, FinanceTotals(1000, 0, 100, 200).error())
    }

    @Test fun week_isMondayToSunday_acrossMonthBoundary() {
        val r = Periods.range(PeriodMode.WEEK, LocalDate.of(2025, 4, 2), LocalDate.now(), LocalDate.now())
        assertEquals(LocalDate.of(2025, 3, 31), r.from)
        assertEquals(LocalDate.of(2025, 4, 6), r.to)
    }

    @Test fun month_handlesLeapYearAndYearEnd() {
        val feb2024 = Periods.range(PeriodMode.MONTH, LocalDate.of(2024, 2, 10), LocalDate.now(), LocalDate.now())
        assertEquals(LocalDate.of(2024, 2, 29), feb2024.to)
        val feb2025 = Periods.range(PeriodMode.MONTH, LocalDate.of(2025, 2, 10), LocalDate.now(), LocalDate.now())
        assertEquals(LocalDate.of(2025, 2, 28), feb2025.to)
        val dec = Periods.range(PeriodMode.MONTH, LocalDate.of(2025, 12, 31), LocalDate.now(), LocalDate.now())
        assertEquals(LocalDate.of(2025, 12, 1), dec.from)
        assertEquals(LocalDate.of(2025, 12, 31), dec.to)
    }

    @Test fun year_andCustomRange() {
        val y = Periods.range(PeriodMode.YEAR, LocalDate.of(2025, 6, 1), LocalDate.now(), LocalDate.now())
        assertEquals(LocalDate.of(2025, 1, 1), y.from)
        assertEquals(LocalDate.of(2025, 12, 31), y.to)
        val swapped = Periods.range(PeriodMode.CUSTOM, LocalDate.now(), LocalDate.of(2025, 5, 10), LocalDate.of(2025, 5, 1))
        assertEquals(LocalDate.of(2025, 5, 1), swapped.from)
        assertEquals(LocalDate.of(2025, 5, 10), swapped.to)
    }

    @Test fun shift_clampsEndOfMonth() {
        assertEquals(LocalDate.of(2025, 2, 28), Periods.shift(PeriodMode.MONTH, LocalDate.of(2025, 1, 31), 1))
        assertEquals(LocalDate.of(2024, 12, 31), Periods.shift(PeriodMode.MONTH, LocalDate.of(2025, 1, 31), -1))
    }

    @Test fun chartGrouping_switchesToMonthsForLongRanges() {
        val short = DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 3, 3)) // 62 дня
        val long = DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 3, 4)) // 63 дня
        assertFalse(StatsCalculator.groupByMonth(short))
        assertTrue(StatsCalculator.groupByMonth(long))
        assertEquals(12, StatsCalculator.buckets(emptyList(), DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31)), true).size)
        assertEquals(31, StatsCalculator.buckets(emptyList(), DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31)), false).size)
    }
}
