@file:OptIn(ExperimentalCoroutinesApi::class)

package com.personalfinance.app.ui.operations

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.TxFilter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OperationsState(
    val items: List<Operation> = emptyList(),
    val categories: List<Category> = emptyList(),
    val filter: TxFilter = TxFilter()
)

class OperationsViewModel(private val repo: FinanceRepository) : ViewModel() {
    private val filter = MutableStateFlow(TxFilter())

    val state: StateFlow<OperationsState> = filter.flatMapLatest { f ->
        combine(repo.operations(f), repo.categories) { ops, cats -> OperationsState(ops, cats, f) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), OperationsState())

    var error by mutableStateOf<FinanceError?>(null)
        private set

    fun setType(type: FlowType?) = filter.update { it.copy(type = type, categoryId = null) }
    fun setCategory(id: Long?) = filter.update { it.copy(categoryId = id) }

    fun setFrom(day: Long?) = filter.update {
        if (day != null && it.toDay != null && day > it.toDay) it.copy(fromDay = day, toDay = day) else it.copy(fromDay = day)
    }

    fun setTo(day: Long?) = filter.update {
        if (day != null && it.fromDay != null && day < it.fromDay) it.copy(fromDay = day, toDay = day) else it.copy(toDay = day)
    }

    fun resetFilters() { filter.value = TxFilter() }
    fun clearError() { error = null }

    fun delete(id: Long) {
        viewModelScope.launch {
            try {
                repo.deleteOperation(id)
            } catch (e: FinanceException) {
                error = e.error
            }
        }
    }
}
