package com.personalfinance.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD0A0),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF1F4D40),
    onPrimaryContainer = Color(0xFFBFF5E1),
    secondaryContainer = Color(0xFF2A3340),
    onSecondaryContainer = Color(0xFFDDE6F3),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE6E8EB),
    surface = Color(0xFF181B21),
    onSurface = Color(0xFFE6E8EB),
    surfaceVariant = Color(0xFF22262E),
    onSurfaceVariant = Color(0xFFA9B0BB),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF3B0A0A),
    outline = Color(0xFF3A404B)
)

object FinanceColors {
    val income = Color(0xFF4CD08B)
    val expense = Color(0xFFFF6B6B)
    val savings = Color(0xFF5AA9FF)
    val palette = listOf(
        Color(0xFF4CD08B), Color(0xFF5AA9FF), Color(0xFFFFB454), Color(0xFFB48CFF),
        Color(0xFFFF6B6B), Color(0xFF45D1D8), Color(0xFFE5D75C), Color(0xFFFF8FC4),
        Color(0xFF9AA5B1), Color(0xFF8BC34A), Color(0xFFFF7043)
    )
}

@Composable
fun PersonalFinanceTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
