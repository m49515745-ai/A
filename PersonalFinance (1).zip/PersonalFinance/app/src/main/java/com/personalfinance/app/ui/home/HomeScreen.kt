package com.personalfinance.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.R
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.BarChart
import com.personalfinance.app.ui.common.EmptyState
import com.personalfinance.app.ui.common.MoneyLine
import com.personalfinance.app.ui.common.OperationRow
import com.personalfinance.app.ui.theme.FinanceColors
import java.time.YearMonth

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onTransferToSavings: () -> Unit,
    onOpenOperation: (Operation) -> Unit,
    onOpenAllOperations: () -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) vm.refreshMonth()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val months = stringArrayResource(R.array.months)
    val ym = YearMonth.now()
    val monthTitle = "${months[ym.monthValue - 1]} ${ym.year}"

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(stringResource(R.string.tab_home), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            AppCard {
                Text(stringResource(R.string.home_available), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Money.withCurrency(state.totals.available), style = MaterialTheme.typography.headlineLarge)
                Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MoneyLine(stringResource(R.string.home_savings), state.totals.savings, FinanceColors.savings)
                    MoneyLine(stringResource(R.string.home_total), state.totals.total)
                }
            }
        }
        item {
            Text(monthTitle, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppCard(Modifier.weight(1f)) {
                    Text(stringResource(R.string.home_income_month), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Money.withCurrency(state.monthIncome), style = MaterialTheme.typography.titleMedium, color = FinanceColors.income)
                }
                AppCard(Modifier.weight(1f)) {
                    Text(stringResource(R.string.home_expense_month), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Money.withCurrency(state.monthExpense), style = MaterialTheme.typography.titleMedium, color = FinanceColors.expense)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onAddIncome, modifier = Modifier.weight(1f)) {
                    Text("+ " + stringResource(R.string.type_income), maxLines = 1)
                }
                Button(
                    onClick = onAddExpense,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)
                ) {
                    Text("+ " + stringResource(R.string.type_expense), maxLines = 1)
                }
            }
            OutlinedButton(onClick = onTransferToSavings, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(stringResource(R.string.home_to_savings))
            }
        }
        item {
            AppCard {
                Text(stringResource(R.string.home_chart_title), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                BarChart(state.buckets, monthLabels = false)
            }
        }
        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(stringResource(R.string.home_recent), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = onOpenAllOperations) { Text(stringResource(R.string.home_all)) }
                }
                if (state.recent.isEmpty()) {
                    EmptyState(stringResource(R.string.ops_empty))
                } else {
                    state.recent.forEach { op ->
                        OperationRow(op, state.categories[op.categoryId], onClick = { onOpenOperation(op) })
                    }
                }
            }
        }
        item { androidx.compose.foundation.layout.Spacer(Modifier.padding(4.dp)) }
    }
}
