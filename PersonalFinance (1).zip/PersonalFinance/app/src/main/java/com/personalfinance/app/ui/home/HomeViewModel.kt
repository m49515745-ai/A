@file:OptIn(ExperimentalCoroutinesApi::class)

package com.personalfinance.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.Bucket
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.DateRange
import com.personalfinance.app.domain.FinanceTotals
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.StatsCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import java.time.YearMonth

data class HomeState(
    val totals: FinanceTotals = FinanceTotals(0, 0, 0, 0),
    val monthIncome: Long = 0,
    val monthExpense: Long = 0,
    val buckets: List<Bucket> = emptyList(),
    val recent: List<Operation> = emptyList(),
    val categories: Map<Long, Category> = emptyMap()
)

class HomeViewModel(private val repo: FinanceRepository) : ViewModel() {
    private val month = MutableStateFlow(YearMonth.now())

    val state: StateFlow<HomeState> = month.flatMapLatest { ym ->
        val range = DateRange(ym.atDay(1), ym.atEndOfMonth())
        combine(
            repo.totals,
            repo.operationsInRange(range.fromDay, range.toDay),
            repo.recentOperations(5),
            repo.categories
        ) { totals, ops, recent, cats ->
            val s = StatsCalculator.summary(ops)
            HomeState(
                totals = totals,
                monthIncome = s.income,
                monthExpense = s.expense,
                buckets = StatsCalculator.buckets(ops, range, byMonth = false),
                recent = recent,
                categories = cats.associateBy { it.id }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    /** Вызывается при возврате в приложение, чтобы «текущий месяц» не устаревал. */
    fun refreshMonth() {
        month.value = YearMonth.now()
    }
}
