@file:OptIn(ExperimentalCoroutinesApi::class)

package com.personalfinance.app.ui.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.Bucket
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.CategorySlice
import com.personalfinance.app.domain.DateRange
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.PeriodMode
import com.personalfinance.app.domain.Periods
import com.personalfinance.app.domain.StatsCalculator
import com.personalfinance.app.domain.Summary
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.time.LocalDate
import java.time.YearMonth

data class StatsQuery(
    val mode: PeriodMode = PeriodMode.MONTH,
    val anchor: LocalDate = LocalDate.now(),
    val customFrom: LocalDate = LocalDate.now().withDayOfMonth(1),
    val customTo: LocalDate = LocalDate.now()
) {
    val range: DateRange get() = Periods.range(mode, anchor, customFrom, customTo)
}

data class StatsState(
    val query: StatsQuery = StatsQuery(),
    val summary: Summary = Summary(0, 0, 0, 0),
    val buckets: List<Bucket> = emptyList(),
    val byMonth: Boolean = false,
    val expenseSlices: List<CategorySlice> = emptyList(),
    val incomeSlices: List<CategorySlice> = emptyList(),
    val comparison: List<Bucket> = emptyList(),
    val categories: Map<Long, Category> = emptyMap()
)

class StatsViewModel(private val repo: FinanceRepository) : ViewModel() {
    private val query = MutableStateFlow(StatsQuery())

    val state: StateFlow<StatsState> = query.flatMapLatest { q ->
        val range = q.range
        val cmpEnd = YearMonth.from(range.to)
        val cmpStart = cmpEnd.minusMonths(5)
        val cmpRange = DateRange(cmpStart.atDay(1), cmpEnd.atEndOfMonth())
        combine(
            repo.operationsInRange(range.fromDay, range.toDay),
            repo.operationsInRange(cmpRange.fromDay, cmpRange.toDay),
            repo.categories
        ) { ops, cmpOps, cats ->
            val byMonth = StatsCalculator.groupByMonth(range)
            StatsState(
                query = q,
                summary = StatsCalculator.summary(ops),
                buckets = StatsCalculator.buckets(ops, range, byMonth),
                byMonth = byMonth,
                expenseSlices = StatsCalculator.categorySlices(ops, FlowType.EXPENSE),
                incomeSlices = StatsCalculator.categorySlices(ops, FlowType.INCOME),
                comparison = StatsCalculator.buckets(cmpOps, cmpRange, byMonth = true),
                categories = cats.associateBy { it.id }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsState())

    fun setMode(mode: PeriodMode) = query.update { it.copy(mode = mode, anchor = LocalDate.now()) }
    fun shift(steps: Long) = query.update { it.copy(anchor = Periods.shift(it.mode, it.anchor, steps)) }

    fun setCustomFrom(day: Long) = query.update {
        val d = LocalDate.ofEpochDay(day)
        it.copy(customFrom = d, customTo = if (d.isAfter(it.customTo)) d else it.customTo)
    }

    fun setCustomTo(day: Long) = query.update {
        val d = LocalDate.ofEpochDay(day)
        it.copy(customTo = d, customFrom = if (d.isBefore(it.customFrom)) d else it.customFrom)
    }
}
