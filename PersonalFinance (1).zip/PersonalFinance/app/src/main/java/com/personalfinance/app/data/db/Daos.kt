package com.personalfinance.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY isSystem DESC, id ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories ORDER BY id ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): CategoryEntity?

    @Query("SELECT * FROM categories WHERE systemKey = :key")
    suspend fun getBySystemKey(key: String): CategoryEntity?

    @Query("SELECT COUNT(*) FROM transactions WHERE categoryId = :id")
    suspend fun usageCount(id: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(e: CategoryEntity): Long

    @Insert
    suspend fun insert(e: CategoryEntity): Long

    @Insert
    suspend fun insertAll(list: List<CategoryEntity>)

    @Update
    suspend fun update(e: CategoryEntity)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM categories")
    suspend fun deleteAll()
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, createdAt DESC, id DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<TransactionEntity>>

    @Query(
        """SELECT * FROM transactions
           WHERE (:type IS NULL OR type = :type)
             AND (:categoryId IS NULL OR categoryId = :categoryId)
             AND (:fromDay IS NULL OR date >= :fromDay)
             AND (:toDay IS NULL OR date <= :toDay)
           ORDER BY date DESC, createdAt DESC, id DESC"""
    )
    fun observeFiltered(type: String?, categoryId: Long?, fromDay: Long?, toDay: Long?): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE date BETWEEN :fromDay AND :toDay ORDER BY date DESC, createdAt DESC, id DESC")
    fun observeInRange(fromDay: Long, toDay: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: Long): TransactionEntity?

    @Query("SELECT * FROM transactions ORDER BY id ASC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun count(): Int

    @Query("SELECT COALESCE(SUM(amountMinor), 0) FROM transactions WHERE type = :type")
    fun observeSum(type: String): Flow<Long>

    @Query("SELECT COALESCE(SUM(amountMinor), 0) FROM transactions WHERE type = :type")
    suspend fun sum(type: String): Long

    @Insert
    suspend fun insert(e: TransactionEntity): Long

    @Insert
    suspend fun insertAll(list: List<TransactionEntity>)

    @Update
    suspend fun update(e: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()
}

@Dao
interface SavingsDao {
    @Query("SELECT * FROM savings_transfers ORDER BY date DESC, createdAt DESC, id DESC")
    fun observeAll(): Flow<List<SavingsTransferEntity>>

    @Query("SELECT * FROM savings_transfers ORDER BY id ASC")
    suspend fun getAll(): List<SavingsTransferEntity>

    @Query("SELECT * FROM savings_transfers WHERE id = :id")
    suspend fun getById(id: Long): SavingsTransferEntity?

    @Query("SELECT COUNT(*) FROM savings_transfers")
    suspend fun count(): Int

    @Query("SELECT COALESCE(SUM(amountMinor), 0) FROM savings_transfers WHERE direction = :direction")
    fun observeSum(direction: String): Flow<Long>

    @Query("SELECT COALESCE(SUM(amountMinor), 0) FROM savings_transfers WHERE direction = :direction")
    suspend fun sum(direction: String): Long

    @Insert
    suspend fun insert(e: SavingsTransferEntity): Long

    @Insert
    suspend fun insertAll(list: List<SavingsTransferEntity>)

    @Update
    suspend fun update(e: SavingsTransferEntity)

    @Query("DELETE FROM savings_transfers WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM savings_transfers")
    suspend fun deleteAll()
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun observe(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun get(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: AppSettingsEntity)
}
