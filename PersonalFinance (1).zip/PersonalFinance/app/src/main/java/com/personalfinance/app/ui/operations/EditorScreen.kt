package com.personalfinance.app.ui.operations

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.R
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.ui.common.DateField
import com.personalfinance.app.ui.common.ErrorDialog
import com.personalfinance.app.ui.common.ScreenHeader
import com.personalfinance.app.ui.common.categoryName

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val categories by vm.categories.collectAsStateWithLifecycle()
    val selected = vm.categoryId ?: categories.firstOrNull()?.id

    LaunchedEffect(vm.done) { if (vm.done) onBack() }

    val title = when {
        vm.type == FlowType.INCOME && !vm.isEdit -> R.string.editor_new_income
        vm.type == FlowType.INCOME -> R.string.editor_edit_income
        !vm.isEdit -> R.string.editor_new_expense
        else -> R.string.editor_edit_expense
    }

    Column(
        Modifier.imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(stringResource(title), onBack)

        OutlinedTextField(
            value = vm.amount,
            onValueChange = { v ->
                if (v.length <= 12 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                    vm.amount = v
                    vm.amountInvalid = false
                }
            },
            label = { Text(stringResource(R.string.field_amount) + " (TMT)") },
            isError = vm.amountInvalid,
            supportingText = if (vm.amountInvalid) ({ Text(stringResource(R.string.err_amount_invalid)) }) else null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text(stringResource(R.string.field_category), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            categories.forEach { c ->
                FilterChip(
                    selected = selected == c.id,
                    onClick = { vm.categoryId = c.id },
                    label = { Text(categoryName(c)) }
                )
            }
        }

        DateField(stringResource(R.string.field_date), vm.date, onPicked = { vm.date = it }, modifier = Modifier.fillMaxWidth())

        OutlinedTextField(
            value = vm.comment,
            onValueChange = { if (it.length <= 500) vm.comment = it },
            label = { Text(stringResource(R.string.field_comment)) },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = vm::save, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), enabled = !vm.done) {
            Text(stringResource(R.string.action_save))
        }
    }
    ErrorDialog(vm.error, onDismiss = vm::clearError)
}
