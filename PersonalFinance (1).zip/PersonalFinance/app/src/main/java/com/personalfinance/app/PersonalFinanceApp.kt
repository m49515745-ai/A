package com.personalfinance.app

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PersonalFinanceApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val container = AppContainer.get(this)
        // Создаёт стандартные категории при первом запуске (повторный вызов безопасен).
        CoroutineScope(Dispatchers.IO).launch { container.finance.ensureSystemCategories() }
    }
}
