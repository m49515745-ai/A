package com.personalfinance.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * Принимает ночной сигнал (отправляет отчёт и ставит следующий) и системные события
 * (перезагрузка, смена времени/часового пояса, обновление приложения), после которых сигнал нужно поставить заново.
 */
class DailyReportReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = NotifyPrefs(app)
                if (!prefs.enabled) return@launch
                if (intent.action == DailyReportScheduler.ACTION_REPORT) {
                    val target = intent.getLongExtra(DailyReportScheduler.EXTRA_TARGET_DAY, LocalDate.now().toEpochDay())
                    // Сначала ставим следующий сигнал: даже если отправка упадёт, завтрашний отчёт не потеряется.
                    DailyReportScheduler.schedule(app, DailyReportTime.baseAfterFire(ZonedDateTime.now(), target))
                    DailyReportJob.post(app, DailyReportTime.reportDayFor(target))
                } else {
                    DailyReportScheduler.schedule(app)
                    DailyReportJob.catchUp(app)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
