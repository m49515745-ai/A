package com.personalfinance.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

enum class PeriodMode { WEEK, MONTH, YEAR, CUSTOM }

data class DateRange(val from: LocalDate, val to: LocalDate) {
    val fromDay: Long get() = from.toEpochDay()
    val toDay: Long get() = to.toEpochDay()
    val days: Long get() = toDay - fromDay + 1
}

object Periods {
    fun range(mode: PeriodMode, anchor: LocalDate, customFrom: LocalDate, customTo: LocalDate): DateRange =
        when (mode) {
            PeriodMode.WEEK -> {
                val start = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                DateRange(start, start.plusDays(6))
            }
            PeriodMode.MONTH -> {
                val ym = YearMonth.from(anchor)
                DateRange(ym.atDay(1), ym.atEndOfMonth())
            }
            PeriodMode.YEAR -> DateRange(LocalDate.of(anchor.year, 1, 1), LocalDate.of(anchor.year, 12, 31))
            PeriodMode.CUSTOM ->
                if (customFrom <= customTo) DateRange(customFrom, customTo) else DateRange(customTo, customFrom)
        }

    fun shift(mode: PeriodMode, anchor: LocalDate, steps: Long): LocalDate = when (mode) {
        PeriodMode.WEEK -> anchor.plusWeeks(steps)
        PeriodMode.MONTH -> anchor.plusMonths(steps)
        PeriodMode.YEAR -> anchor.plusYears(steps)
        PeriodMode.CUSTOM -> anchor
    }
}

data class Summary(val income: Long, val expense: Long, val incomeCount: Int, val expenseCount: Int) {
    val net: Long get() = income - expense
}

/** Столбец графика: день (epochDay) или первый день месяца. */
data class Bucket(val startDay: Long, val income: Long, val expense: Long)

data class CategorySlice(val categoryId: Long, val amount: Long, val count: Int)

/** Переводы в сбережения сюда не попадают: считаются только доходы и расходы. */
object StatsCalculator {
    const val MAX_DAY_BUCKETS = 62

    fun summary(ops: List<Operation>): Summary {
        var inc = 0L; var exp = 0L; var ic = 0; var ec = 0
        for (o in ops) {
            if (o.type == FlowType.INCOME) { inc += o.amountMinor; ic++ } else { exp += o.amountMinor; ec++ }
        }
        return Summary(inc, exp, ic, ec)
    }

    fun groupByMonth(range: DateRange): Boolean = range.days > MAX_DAY_BUCKETS

    fun buckets(ops: List<Operation>, range: DateRange, byMonth: Boolean): List<Bucket> {
        if (!byMonth) {
            val inc = HashMap<Long, Long>(); val exp = HashMap<Long, Long>()
            for (o in ops) {
                val m = if (o.type == FlowType.INCOME) inc else exp
                m[o.date] = (m[o.date] ?: 0L) + o.amountMinor
            }
            return (range.fromDay..range.toDay).map { Bucket(it, inc[it] ?: 0L, exp[it] ?: 0L) }
        }
        val inc = HashMap<Long, Long>(); val exp = HashMap<Long, Long>()
        for (o in ops) {
            val key = YearMonth.from(LocalDate.ofEpochDay(o.date)).atDay(1).toEpochDay()
            val m = if (o.type == FlowType.INCOME) inc else exp
            m[key] = (m[key] ?: 0L) + o.amountMinor
        }
        val result = ArrayList<Bucket>()
        var ym = YearMonth.from(range.from)
        val last = YearMonth.from(range.to)
        while (!ym.isAfter(last)) {
            val key = ym.atDay(1).toEpochDay()
            result.add(Bucket(key, inc[key] ?: 0L, exp[key] ?: 0L))
            ym = ym.plusMonths(1)
        }
        return result
    }

    fun categorySlices(ops: List<Operation>, type: FlowType): List<CategorySlice> =
        ops.filter { it.type == type }
            .groupBy { it.categoryId }
            .map { (id, list) -> CategorySlice(id, list.sumOf { it.amountMinor }, list.size) }
            .sortedByDescending { it.amount }
}
