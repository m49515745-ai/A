package com.personalfinance.app.notify

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.personalfinance.app.AppContainer
import com.personalfinance.app.MainActivity
import com.personalfinance.app.R
import com.personalfinance.app.domain.Money
import com.personalfinance.app.ui.common.categoryLabel
import com.personalfinance.app.ui.common.formatDate
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.util.Locale

object DailyReportJob {
    const val CHANNEL_ID = "daily_report"
    private const val TEST_NOTIFICATION_ID = 9001

    /**
     * Показывает уведомление с суммой расходов за день [day].
     * [force] = true — для кнопки «Показать пример»: игнорирует «уже отправлено» и не запоминает отправку.
     * Возвращает false, если уведомление не показано (уже отправлено или уведомления запрещены).
     */
    @SuppressLint("MissingPermission")
    suspend fun post(context: Context, day: Long, force: Boolean = false): Boolean {
        val app = context.applicationContext
        val prefs = NotifyPrefs(app)
        if (!force && prefs.lastReportedDay >= day) return false

        val manager = NotificationManagerCompat.from(app)
        if (!manager.areNotificationsEnabled()) return false

        val container = AppContainer.get(app)
        val ops = container.finance.operationsInRange(day, day).first()
        val categories = container.finance.categories.first().associateBy { it.id }
        val language = container.settings.getLanguage()

        // Текст уведомления — на языке приложения, а не на языке телефона.
        val config = Configuration(app.resources.configuration)
        config.setLocale(Locale.forLanguageTag(language))
        val localized = app.createConfigurationContext(config)

        val data = DailyReportBuilder.build(day, ops)
        val title = localized.getString(R.string.notif_title, formatDate(day))
        val text = if (data.count == 0) {
            localized.getString(R.string.notif_text_none)
        } else {
            localized.getString(R.string.notif_text_total, Money.withCurrency(data.total), data.count)
        }
        val details = buildString {
            append(text)
            data.top.forEach {
                append('\n')
                append(categoryLabel(localized, categories[it.categoryId]))
                append(" — ")
                append(Money.withCurrency(it.amount))
            }
        }

        manager.createNotificationChannel(
            NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName(localized.getString(R.string.notif_channel_name))
                .build()
        )
        val open = PendingIntent.getActivity(
            app, 0,
            Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_report)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(details))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        val id = if (force) TEST_NOTIFICATION_ID else 10_000 + (day % 100_000).toInt()
        manager.notify(id, notification)
        if (!force) prefs.lastReportedDay = day
        return true
    }

    /**
     * Если за вчера отчёт не отправлялся (телефон был выключен в полночь, система погасила сигнал),
     * отправляет его сейчас. Позавчера и раньше не догоняет.
     */
    suspend fun catchUp(context: Context) {
        val prefs = NotifyPrefs(context)
        if (!prefs.enabled) return
        val yesterday = LocalDate.now().toEpochDay() - 1
        val last = prefs.lastReportedDay
        if (last in 0 until yesterday) post(context, yesterday)
    }
}
