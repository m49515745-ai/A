package com.personalfinance.app.domain

import java.time.LocalDate

enum class FlowType { INCOME, EXPENSE }

enum class TransferDirection { TO_SAVINGS, FROM_SAVINGS }

/** Причины, по которым финансовая операция отклоняется. UI превращает их в локализованный текст. */
enum class FinanceError {
    INSUFFICIENT_BALANCE,
    INSUFFICIENT_SAVINGS,
    INVALID_AMOUNT,
    INVALID_DATE,
    CATEGORY_MISMATCH,
    CATEGORY_NOT_FOUND,
    NOT_FOUND,
    CATEGORY_IN_USE,
    CATEGORY_PROTECTED,
    EMPTY_NAME,
    NAME_EXISTS
}

class FinanceException(val error: FinanceError) : Exception(error.name)

data class Category(
    val id: Long,
    val type: FlowType,
    val systemKey: String?,
    val customName: String?,
    val isSystem: Boolean
)

/** Операция дохода или расхода. Сумма в тенге (1/100 TMT), дата — epochDay. */
data class Operation(
    val id: Long,
    val type: FlowType,
    val amountMinor: Long,
    val categoryId: Long,
    val date: Long,
    val comment: String?,
    val createdAt: Long,
    val updatedAt: Long
)

data class Transfer(
    val id: Long,
    val direction: TransferDirection,
    val amountMinor: Long,
    val date: Long,
    val comment: String?,
    val createdAt: Long,
    val updatedAt: Long
)

data class TxFilter(
    val type: FlowType? = null,
    val categoryId: Long? = null,
    val fromDay: Long? = null,
    val toDay: Long? = null
)

/**
 * Итоговые суммы, из которых выводится всё остальное. Сами по себе нигде не хранятся —
 * всегда пересчитываются из сохранённых записей.
 */
data class FinanceTotals(
    val income: Long,
    val expense: Long,
    val toSavings: Long,
    val fromSavings: Long
) {
    val available: Long get() = income - expense - toSavings + fromSavings
    val savings: Long get() = toSavings - fromSavings
    val total: Long get() = available + savings

    /** null — состояние допустимо. */
    fun error(): FinanceError? = when {
        available < 0 -> FinanceError.INSUFFICIENT_BALANCE
        savings < 0 -> FinanceError.INSUFFICIENT_SAVINGS
        else -> null
    }
}

object SystemCategories {
    val income = listOf("clothes", "mom", "other_income")
    val expense = listOf("food", "taxi", "drinks", "debts", "ads", "donation", "groceries", "other")
    val all: List<Pair<FlowType, String>> =
        income.map { FlowType.INCOME to it } + expense.map { FlowType.EXPENSE to it }

    fun typeOf(key: String): FlowType? = all.firstOrNull { it.second == key }?.first
}

object Dates {
    val MIN_DAY: Long = LocalDate.of(2000, 1, 1).toEpochDay()
    val MAX_DAY: Long = LocalDate.of(2100, 12, 31).toEpochDay()
    fun isValid(epochDay: Long) = epochDay in MIN_DAY..MAX_DAY
}
