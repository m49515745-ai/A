package com.personalfinance.app.ui.settings

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.backup.BackupData
import com.personalfinance.app.data.backup.BackupError
import com.personalfinance.app.data.backup.BackupException
import com.personalfinance.app.data.backup.BackupManager
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.data.repo.SettingsRepository
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FlowType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

sealed interface SettingsMessage {
    data object ExportDone : SettingsMessage
    data object ExportFailed : SettingsMessage
    data class ImportDone(val operations: Int) : SettingsMessage
    data class ImportFailed(val error: BackupError) : SettingsMessage
    data class Finance(val error: FinanceError) : SettingsMessage
}

class SettingsViewModel(
    private val repo: FinanceRepository,
    private val settings: SettingsRepository,
    private val backup: BackupManager,
    private val resolver: ContentResolver
) : ViewModel() {
    val language: StateFlow<String> = settings.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsRepository.DEFAULT_LANGUAGE)

    val categories: StateFlow<List<Category>> = repo.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    var message by mutableStateOf<SettingsMessage?>(null)
        private set

    /** Проверенная, но ещё не применённая копия — ждёт подтверждения пользователя. */
    var pendingImport by mutableStateOf<BackupData?>(null)
        private set

    fun clearMessage() { message = null }
    fun cancelImport() { pendingImport = null }

    fun setLanguage(code: String) {
        viewModelScope.launch { settings.setLanguage(code) }
    }

    fun addCategory(type: FlowType, name: String) = financeAction { repo.addCategory(type, name) }
    fun renameCategory(id: Long, name: String) = financeAction { repo.renameCategory(id, name) }
    fun deleteCategory(id: Long) = financeAction { repo.deleteCategory(id) }

    private fun financeAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: FinanceException) {
                message = SettingsMessage.Finance(e.error)
            }
        }
    }

    fun export(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = backup.exportJson()
                withContext(Dispatchers.IO) {
                    val out = resolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("no stream")
                    out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }
                message = SettingsMessage.ExportDone
            } catch (e: Exception) {
                message = SettingsMessage.ExportFailed
            }
        }
    }

    /** Шаг 1: прочитать и проверить файл. База не меняется. */
    fun prepareImport(uri: Uri) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val input = resolver.openInputStream(uri) ?: throw BackupException(BackupError.CORRUPTED)
                    input.use { readLimited(it) }
                }
                pendingImport = backup.parse(text)
            } catch (e: BackupException) {
                message = SettingsMessage.ImportFailed(e.error)
            } catch (e: Exception) {
                message = SettingsMessage.ImportFailed(BackupError.CORRUPTED)
            }
        }
    }

    /** Шаг 2: после подтверждения заменить данные (атомарно). */
    fun confirmImport() {
        val data = pendingImport ?: return
        pendingImport = null
        viewModelScope.launch {
            try {
                backup.restore(data)
                message = SettingsMessage.ImportDone(data.transactions.size)
            } catch (e: BackupException) {
                message = SettingsMessage.ImportFailed(e.error)
            }
        }
    }

    private fun readLimited(input: InputStream): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_BACKUP_BYTES) throw BackupException(BackupError.CORRUPTED)
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }

    private companion object {
        const val MAX_BACKUP_BYTES = 20 * 1024 * 1024
    }
}
