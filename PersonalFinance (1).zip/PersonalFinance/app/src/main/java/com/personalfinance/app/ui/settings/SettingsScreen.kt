package com.personalfinance.app.ui.settings

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.personalfinance.app.notify.DailyReportJob
import com.personalfinance.app.notify.DailyReportScheduler
import com.personalfinance.app.notify.NotifyPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.BuildConfig
import com.personalfinance.app.R
import com.personalfinance.app.data.backup.BackupError
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.ConfirmDeleteDialog
import com.personalfinance.app.ui.common.categoryName
import com.personalfinance.app.ui.common.errorRes
import java.time.LocalDate
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: SettingsViewModel) {
    val language by vm.language.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    var addDialog by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Category?>(null) }
    var deleting by remember { mutableStateOf<Category?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.export(uri) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.prepareImport(uri) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(stringResource(R.string.tab_settings), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp)) }

        item {
            AppCard {
                Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = language == "ru", onClick = { vm.setLanguage("ru") }, label = { Text(stringResource(R.string.lang_ru)) })
                    FilterChip(selected = language == "tk", onClick = { vm.setLanguage("tk") }, label = { Text(stringResource(R.string.lang_tk)) })
                }
            }
        }

        item { NotificationsCard() }

        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.settings_categories), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { addDialog = true }) { Text("+ " + stringResource(R.string.cat_add)) }
                }
                categories.forEach { c ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(categoryName(c), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                stringResource(if (c.type == FlowType.INCOME) R.string.type_income else R.string.type_expense) +
                                    if (c.isSystem) " · " + stringResource(R.string.cat_system) else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!c.isSystem) {
                            IconButton(onClick = { renaming = c }) {
                                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.cat_rename), modifier = Modifier.size(20.dp))
                            }
                            IconButton(onClick = { deleting = c }) {
                                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete), modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            AppCard {
                Text(stringResource(R.string.settings_backup), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.backup_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(
                    onClick = {
                        val d = LocalDate.now()
                        val name = String.format(Locale.ROOT, "personal-finance-backup-%04d%02d%02d.json", d.year, d.monthValue, d.dayOfMonth)
                        exportLauncher.launch(name)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.backup_export)) }
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text(stringResource(R.string.backup_import)) }
            }
        }

        item {
            AppCard {
                Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.app_name) + " " + stringResource(R.string.about_version, BuildConfig.VERSION_NAME), modifier = Modifier.padding(top = 4.dp))
                Text(
                    stringResource(R.string.about_offline),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        item { Spacer(Modifier.padding(4.dp)) }
    }

    if (addDialog) {
        CategoryNameDialog(
            title = stringResource(R.string.cat_add),
            initial = "",
            showTypePicker = true,
            onDismiss = { addDialog = false },
            onConfirm = { type, name -> vm.addCategory(type, name); addDialog = false }
        )
    }
    renaming?.let { c ->
        CategoryNameDialog(
            title = stringResource(R.string.cat_rename),
            initial = c.customName ?: "",
            showTypePicker = false,
            onDismiss = { renaming = null },
            onConfirm = { _, name -> vm.renameCategory(c.id, name); renaming = null }
        )
    }
    deleting?.let { c ->
        ConfirmDeleteDialog(
            message = stringResource(R.string.cat_delete_confirm, categoryName(c)),
            onConfirm = { vm.deleteCategory(c.id); deleting = null },
            onDismiss = { deleting = null }
        )
    }

    vm.pendingImport?.let { data ->
        AlertDialog(
            onDismissRequest = vm::cancelImport,
            title = { Text(stringResource(R.string.backup_import_confirm_title)) },
            text = {
                Text(stringResource(R.string.backup_import_confirm_text, data.transactions.size, data.transfers.size, data.categories.size))
            },
            confirmButton = {
                TextButton(onClick = vm::confirmImport) {
                    Text(stringResource(R.string.backup_import_replace), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = vm::cancelImport) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    vm.message?.let { m ->
        val text = when (m) {
            SettingsMessage.ExportDone -> stringResource(R.string.backup_export_done)
            SettingsMessage.ExportFailed -> stringResource(R.string.backup_export_failed)
            is SettingsMessage.ImportDone -> stringResource(R.string.backup_import_done, m.operations)
            is SettingsMessage.ImportFailed -> stringResource(
                when (m.error) {
                    BackupError.CORRUPTED -> R.string.import_err_corrupted
                    BackupError.UNSUPPORTED_VERSION -> R.string.import_err_version
                    BackupError.INVALID_DATA -> R.string.import_err_invalid
                    BackupError.INCONSISTENT -> R.string.import_err_inconsistent
                    BackupError.RESTORE_FAILED -> R.string.import_err_restore
                }
            )
            is SettingsMessage.Finance -> stringResource(errorRes(m.error))
        }
        AlertDialog(
            onDismissRequest = vm::clearMessage,
            text = { Text(text) },
            confirmButton = { TextButton(onClick = vm::clearMessage) { Text(stringResource(R.string.action_ok)) } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CategoryNameDialog(
    title: String,
    initial: String,
    showTypePicker: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (FlowType, String) -> Unit
) {
    var name by remember { mutableStateOf(initial) }
    var type by remember { mutableStateOf(FlowType.EXPENSE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (showTypePicker) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(type == FlowType.EXPENSE, { type = FlowType.EXPENSE }, { Text(stringResource(R.string.type_expense)) })
                        FilterChip(type == FlowType.INCOME, { type = FlowType.INCOME }, { Text(stringResource(R.string.type_income)) })
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 40) name = it },
                    label = { Text(stringResource(R.string.cat_name)) },
                    singleLine = true
                )
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(type, name) }) { Text(stringResource(R.string.action_save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@Composable
private fun NotificationsCard() {
    val context = LocalContext.current
    val prefs = remember { NotifyPrefs(context) }
    val scope = rememberCoroutineScope()

    fun hasPermission() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    var enabled by remember { mutableStateOf(prefs.enabled && hasPermission()) }
    var info by remember { mutableStateOf<Int?>(null) }

    fun enable() {
        prefs.enabled = true
        prefs.lastReportedDay = java.time.LocalDate.now().toEpochDay() - 1
        DailyReportScheduler.schedule(context)
        enabled = true
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) enable() else info = R.string.notif_permission_denied
    }

    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.settings_notifications), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.notif_daily_switch), modifier = Modifier.padding(top = 4.dp))
            }
            Switch(
                checked = enabled,
                onCheckedChange = { on ->
                    if (on) {
                        if (hasPermission()) enable() else permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        prefs.enabled = false
                        DailyReportScheduler.cancel(context)
                        enabled = false
                    }
                }
            )
        }
        Text(
            stringResource(R.string.notif_daily_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        OutlinedButton(
            onClick = {
                if (!hasPermission()) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    scope.launch {
                        val shown = withContext(Dispatchers.IO) {
                            DailyReportJob.post(context, java.time.LocalDate.now().toEpochDay() - 1, force = true)
                        }
                        if (!shown) info = R.string.notif_permission_denied
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.notif_test)) }
    }

    info?.let { res ->
        AlertDialog(
            onDismissRequest = { info = null },
            text = { Text(stringResource(res)) },
            confirmButton = { TextButton(onClick = { info = null }) { Text(stringResource(R.string.action_ok)) } }
        )
    }
}
