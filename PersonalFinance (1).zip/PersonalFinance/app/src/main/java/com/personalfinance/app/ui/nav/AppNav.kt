package com.personalfinance.app.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.personalfinance.app.AppContainer
import com.personalfinance.app.R
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.TransferDirection
import com.personalfinance.app.ui.common.vmFactory
import com.personalfinance.app.ui.home.HomeScreen
import com.personalfinance.app.ui.home.HomeViewModel
import com.personalfinance.app.ui.operations.EditorScreen
import com.personalfinance.app.ui.operations.EditorViewModel
import com.personalfinance.app.ui.operations.OperationsScreen
import com.personalfinance.app.ui.operations.OperationsViewModel
import com.personalfinance.app.ui.savings.SavingsScreen
import com.personalfinance.app.ui.savings.SavingsViewModel
import com.personalfinance.app.ui.savings.TransferEditorScreen
import com.personalfinance.app.ui.savings.TransferEditorViewModel
import com.personalfinance.app.ui.settings.SettingsScreen
import com.personalfinance.app.ui.settings.SettingsViewModel
import com.personalfinance.app.ui.stats.CategoryOperationsScreen
import com.personalfinance.app.ui.stats.CategoryOperationsViewModel
import com.personalfinance.app.ui.stats.StatsScreen
import com.personalfinance.app.ui.stats.StatsViewModel

private const val HOME = "home"
private const val OPERATIONS = "operations"
private const val STATS = "stats"
private const val SAVINGS = "savings"
private const val SETTINGS = "settings"
private const val EDITOR = "editor/{type}/{id}"
private const val TRANSFER = "transfer/{dir}/{id}"
private const val CATEGORY_OPS = "catops/{type}/{cat}/{from}/{to}"

private data class Tab(val route: String, val label: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(HOME, R.string.tab_home, Icons.Filled.Home),
    Tab(OPERATIONS, R.string.tab_operations, Icons.AutoMirrored.Filled.List),
    Tab(STATS, R.string.tab_stats, Icons.Filled.DateRange),
    Tab(SAVINGS, R.string.tab_savings, Icons.Filled.Favorite),
    Tab(SETTINGS, R.string.tab_settings, Icons.Filled.Settings)
)

@Composable
fun AppRoot(container: AppContainer) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = tabs.any { it.route == route }

    fun openEditor(type: FlowType, id: Long) { nav.navigate("editor/${type.name}/$id") }
    fun openTransfer(dir: TransferDirection, id: Long) { nav.navigate("transfer/${dir.name}/$id") }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo(HOME) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(stringResource(tab.label), maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = HOME, modifier = Modifier.padding(padding)) {
            composable(HOME) {
                val vm: HomeViewModel = viewModel(factory = vmFactory { HomeViewModel(container.finance) })
                HomeScreen(
                    vm = vm,
                    onAddIncome = { openEditor(FlowType.INCOME, 0) },
                    onAddExpense = { openEditor(FlowType.EXPENSE, 0) },
                    onTransferToSavings = { openTransfer(TransferDirection.TO_SAVINGS, 0) },
                    onOpenOperation = { openEditor(it.type, it.id) },
                    onOpenAllOperations = {
                        nav.navigate(OPERATIONS) {
                            popUpTo(HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
            composable(OPERATIONS) {
                val vm: OperationsViewModel = viewModel(factory = vmFactory { OperationsViewModel(container.finance) })
                OperationsScreen(vm, onAdd = { openEditor(it, 0) }, onOpen = { openEditor(it.type, it.id) })
            }
            composable(STATS) {
                val vm: StatsViewModel = viewModel(factory = vmFactory { StatsViewModel(container.finance) })
                StatsScreen(vm, onOpenCategory = { type, cat, from, to ->
                    nav.navigate("catops/${type.name}/$cat/$from/$to")
                })
            }
            composable(SAVINGS) {
                val vm: SavingsViewModel = viewModel(factory = vmFactory { SavingsViewModel(container.finance) })
                SavingsScreen(vm, onNewTransfer = { openTransfer(it, 0) }, onOpenTransfer = { openTransfer(it.direction, it.id) })
            }
            composable(SETTINGS) {
                val vm: SettingsViewModel = viewModel(
                    factory = vmFactory {
                        SettingsViewModel(container.finance, container.settings, container.backup, container.appContext.contentResolver)
                    }
                )
                SettingsScreen(vm)
            }
            composable(
                EDITOR,
                arguments = listOf(
                    navArgument("type") { type = NavType.StringType },
                    navArgument("id") { type = NavType.LongType }
                )
            ) { e ->
                val type = FlowType.valueOf(e.arguments?.getString("type") ?: FlowType.EXPENSE.name)
                val id = e.arguments?.getLong("id") ?: 0L
                val vm: EditorViewModel = viewModel(factory = vmFactory { EditorViewModel(container.finance, type, id) })
                EditorScreen(vm, onBack = { nav.popBackStack() })
            }
            composable(
                CATEGORY_OPS,
                arguments = listOf(
                    navArgument("type") { type = NavType.StringType },
                    navArgument("cat") { type = NavType.LongType },
                    navArgument("from") { type = NavType.LongType },
                    navArgument("to") { type = NavType.LongType }
                )
            ) { e ->
                val type = FlowType.valueOf(e.arguments?.getString("type") ?: FlowType.EXPENSE.name)
                val cat = e.arguments?.getLong("cat") ?: 0L
                val from = e.arguments?.getLong("from") ?: 0L
                val to = e.arguments?.getLong("to") ?: 0L
                val vm: CategoryOperationsViewModel = viewModel(
                    factory = vmFactory { CategoryOperationsViewModel(container.finance, type, cat, from, to) }
                )
                CategoryOperationsScreen(
                    vm = vm, type = type, fromDay = from, toDay = to,
                    onBack = { nav.popBackStack() },
                    onOpen = { openEditor(it.type, it.id) }
                )
            }
            composable(
                TRANSFER,
                arguments = listOf(
                    navArgument("dir") { type = NavType.StringType },
                    navArgument("id") { type = NavType.LongType }
                )
            ) { e ->
                val dir = TransferDirection.valueOf(e.arguments?.getString("dir") ?: TransferDirection.TO_SAVINGS.name)
                val id = e.arguments?.getLong("id") ?: 0L
                val vm: TransferEditorViewModel = viewModel(factory = vmFactory { TransferEditorViewModel(container.finance, dir, id) })
                TransferEditorScreen(vm, onBack = { nav.popBackStack() })
            }
        }
    }
}
