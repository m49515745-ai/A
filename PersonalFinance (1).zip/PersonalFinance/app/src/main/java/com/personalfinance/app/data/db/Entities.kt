package com.personalfinance.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.Transfer
import com.personalfinance.app.domain.TransferDirection

@Entity(tableName = "categories", indices = [Index(value = ["systemKey"], unique = true)])
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: FlowType,
    /** Ключ локализации для системных категорий (например "food"); для пользовательских null. */
    val systemKey: String?,
    /** Название пользовательской категории; для системных null. */
    val customName: String?,
    val isSystem: Boolean
)

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("categoryId"), Index("date")]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: FlowType,
    val amountMinor: Long,
    val categoryId: Long,
    /** LocalDate.toEpochDay() — не зависит от часового пояса. */
    val date: Long,
    val comment: String?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "savings_transfers", indices = [Index("date")])
data class SavingsTransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val direction: TransferDirection,
    val amountMinor: Long,
    val date: Long,
    val comment: String?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val language: String
)

fun CategoryEntity.toDomain() = Category(id, type, systemKey, customName, isSystem)
fun TransactionEntity.toDomain() = Operation(id, type, amountMinor, categoryId, date, comment, createdAt, updatedAt)
fun SavingsTransferEntity.toDomain() = Transfer(id, direction, amountMinor, date, comment, createdAt, updatedAt)
