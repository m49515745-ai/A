package com.personalfinance.app.data.repo

import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.db.AppSettingsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

class SettingsRepository(db: AppDatabase) {
    private val dao = db.settingsDao()

    val language: Flow<String> = dao.observe().map { it?.language ?: DEFAULT_LANGUAGE }.distinctUntilChanged()

    suspend fun getLanguage(): String = dao.get()?.language ?: DEFAULT_LANGUAGE

    suspend fun setLanguage(code: String) {
        require(code in SUPPORTED_LANGUAGES) { "Unsupported language: $code" }
        dao.upsert(AppSettingsEntity(1, code))
    }

    companion object {
        const val DEFAULT_LANGUAGE = "ru"
        val SUPPORTED_LANGUAGES = listOf("ru", "tk")
    }
}
