package com.personalfinance.app.ui.stats

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.R
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.TxFilter
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.EmptyState
import com.personalfinance.app.ui.common.ScreenHeader
import com.personalfinance.app.ui.common.categoryName
import com.personalfinance.app.ui.common.formatDate
import com.personalfinance.app.ui.theme.FinanceColors
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class CategoryOpsState(
    val items: List<Operation> = emptyList(),
    val category: Category? = null
)

/** Операции одной категории за период статистики: те же данные, что и в диаграмме. */
class CategoryOperationsViewModel(
    repo: FinanceRepository,
    private val type: FlowType,
    private val categoryId: Long,
    fromDay: Long,
    toDay: Long
) : ViewModel() {
    val state: StateFlow<CategoryOpsState> = combine(
        repo.operations(TxFilter(type = type, categoryId = categoryId, fromDay = fromDay, toDay = toDay)),
        repo.categories
    ) { ops, cats -> CategoryOpsState(ops, cats.firstOrNull { it.id == categoryId }) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CategoryOpsState())
}

@Composable
fun CategoryOperationsScreen(
    vm: CategoryOperationsViewModel,
    type: FlowType,
    fromDay: Long,
    toDay: Long,
    onBack: () -> Unit,
    onOpen: (Operation) -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val color = if (type == FlowType.INCOME) FinanceColors.income else FinanceColors.expense
    val sign = if (type == FlowType.INCOME) "+" else "−"

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader(categoryName(state.category), onBack) }
        item {
            AppCard {
                Text(
                    "${formatDate(fromDay)} – ${formatDate(toDay)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(stringResource(R.string.catops_total), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                Text(Money.withCurrency(state.items.sumOf { it.amountMinor }), style = MaterialTheme.typography.headlineSmall, color = color)
                Text(stringResource(R.string.stats_ops_count, state.items.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (state.items.isEmpty()) {
            item { EmptyState(stringResource(R.string.stats_no_data)) }
        } else {
            items(state.items, key = { it.id }) { op ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(op) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        // Дата — главное: «какого числа».
                        Text(formatDate(op.date), style = MaterialTheme.typography.titleMedium)
                        if (!op.comment.isNullOrBlank()) {
                            Text(
                                op.comment,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(sign + Money.withCurrency(op.amountMinor), style = MaterialTheme.typography.titleMedium, color = color)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            }
        }
        item { Spacer(Modifier.padding(4.dp)) }
    }
}
