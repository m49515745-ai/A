package com.personalfinance.app.ui.stats

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.R
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.PeriodMode
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.BarChart
import com.personalfinance.app.ui.common.CategoryBreakdown
import com.personalfinance.app.ui.common.DateField
import com.personalfinance.app.ui.common.formatDate
import com.personalfinance.app.ui.theme.FinanceColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatsScreen(
    vm: StatsViewModel,
    onOpenCategory: (type: FlowType, categoryId: Long, fromDay: Long, toDay: Long) -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val q = state.query
    val range = q.range
    val months = stringArrayResource(R.array.months)

    val periodLabel = when (q.mode) {
        PeriodMode.WEEK -> "${formatDate(range.fromDay)} – ${formatDate(range.toDay)}"
        PeriodMode.MONTH -> "${months[range.from.monthValue - 1]} ${range.from.year}"
        PeriodMode.YEAR -> range.from.year.toString()
        PeriodMode.CUSTOM -> "${formatDate(range.fromDay)} – ${formatDate(range.toDay)}"
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(stringResource(R.string.tab_stats), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp)) }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(q.mode == PeriodMode.WEEK, { vm.setMode(PeriodMode.WEEK) }, { Text(stringResource(R.string.period_week)) })
                FilterChip(q.mode == PeriodMode.MONTH, { vm.setMode(PeriodMode.MONTH) }, { Text(stringResource(R.string.period_month)) })
                FilterChip(q.mode == PeriodMode.YEAR, { vm.setMode(PeriodMode.YEAR) }, { Text(stringResource(R.string.period_year)) })
                FilterChip(q.mode == PeriodMode.CUSTOM, { vm.setMode(PeriodMode.CUSTOM) }, { Text(stringResource(R.string.period_custom)) })
            }
        }
        item {
            if (q.mode == PeriodMode.CUSTOM) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(stringResource(R.string.filter_from), range.fromDay, onPicked = vm::setCustomFrom, modifier = Modifier.weight(1f))
                    DateField(stringResource(R.string.filter_to), range.toDay, onPicked = vm::setCustomTo, modifier = Modifier.weight(1f))
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.shift(-1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
                    }
                    Text(periodLabel, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.shift(1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppCard(Modifier.weight(1f)) {
                    Text(stringResource(R.string.stats_income), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Money.withCurrency(state.summary.income), style = MaterialTheme.typography.titleMedium, color = FinanceColors.income)
                    Text(stringResource(R.string.stats_ops_count, state.summary.incomeCount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                AppCard(Modifier.weight(1f)) {
                    Text(stringResource(R.string.stats_expense), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Money.withCurrency(state.summary.expense), style = MaterialTheme.typography.titleMedium, color = FinanceColors.expense)
                    Text(stringResource(R.string.stats_ops_count, state.summary.expenseCount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            AppCard {
                Text(stringResource(R.string.stats_net), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Money.withCurrency(state.summary.net), style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            AppCard {
                Text(
                    stringResource(if (state.byMonth) R.string.stats_chart_months else R.string.stats_chart_days),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                BarChart(state.buckets, monthLabels = state.byMonth)
            }
        }
        item {
            AppCard {
                Text(stringResource(R.string.stats_expense_by_cat), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                CategoryBreakdown(state.expenseSlices, state.categories) {
                    onOpenCategory(FlowType.EXPENSE, it.categoryId, range.fromDay, range.toDay)
                }
            }
        }
        item {
            AppCard {
                Text(stringResource(R.string.stats_income_by_cat), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                CategoryBreakdown(state.incomeSlices, state.categories) {
                    onOpenCategory(FlowType.INCOME, it.categoryId, range.fromDay, range.toDay)
                }
            }
        }
        item {
            AppCard {
                Text(stringResource(R.string.stats_compare), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                BarChart(state.comparison, monthLabels = true)
            }
        }
        item { Spacer(Modifier.padding(4.dp)) }
    }
}
