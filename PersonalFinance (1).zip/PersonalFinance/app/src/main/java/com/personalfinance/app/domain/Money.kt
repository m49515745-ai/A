package com.personalfinance.app.domain

/**
 * Деньги хранятся целым числом Long в «тенге» (1 TMT = 100 тенге). Float/Double не используются.
 */
object Money {
    const val CURRENCY = "TMT"
    const val MAX_MINOR = 99_999_999_999L // 999 999 999.99 TMT

    private val INPUT = Regex("""\d{1,9}([.,]\d{1,2})?""")

    /** "12", "12.5", "12,50" -> тенге. null, если ввод некорректен или не положителен. */
    fun parse(input: String): Long? {
        val s = input.trim().replace(" ", "")
        if (!INPUT.matches(s)) return null
        val parts = s.replace(',', '.').split('.')
        val whole = parts[0].toLong()
        val frac = if (parts.size > 1) parts[1].padEnd(2, '0').toLong() else 0L
        val v = whole * 100 + frac
        return if (v in 1..MAX_MINOR) v else null
    }

    /** 123450 -> "1 234.50", 100000 -> "1 000". Неразрывный пробел между тысячами. */
    fun format(minor: Long): String {
        val neg = minor < 0
        val abs = if (neg) -minor else minor
        val whole = (abs / 100).toString().reversed().chunked(3).joinToString("\u00A0").reversed()
        val frac = (abs % 100).toInt()
        val body = if (frac == 0) whole else "$whole.${frac.toString().padStart(2, '0')}"
        return if (neg) "-$body" else body
    }

    fun withCurrency(minor: Long) = "${format(minor)}\u00A0$CURRENCY"

    /** Для заполнения поля ввода при редактировании. */
    fun toInput(minor: Long): String {
        val frac = (minor % 100).toInt()
        return if (frac == 0) (minor / 100).toString() else "${minor / 100}.${frac.toString().padStart(2, '0')}"
    }
}
