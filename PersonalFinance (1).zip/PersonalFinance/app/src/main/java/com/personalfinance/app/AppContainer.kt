package com.personalfinance.app

import android.content.Context
import androidx.room.Room
import com.personalfinance.app.data.backup.BackupManager
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.data.repo.SettingsRepository

/** Простой контейнер зависимостей (без DI-фреймворков). */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext ?: context
    val db: AppDatabase = Room.databaseBuilder(appContext, AppDatabase::class.java, AppDatabase.FILE_NAME).build()
    val finance = FinanceRepository(db)
    val settings = SettingsRepository(db)
    val backup = BackupManager(db)

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun get(context: Context): AppContainer =
            instance ?: synchronized(this) {
                instance ?: AppContainer(context).also { instance = it }
            }
    }
}
