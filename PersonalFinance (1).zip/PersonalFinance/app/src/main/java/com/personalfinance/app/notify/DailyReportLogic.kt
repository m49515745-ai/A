package com.personalfinance.app.notify

import com.personalfinance.app.domain.CategorySlice
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.StatsCalculator
import java.time.LocalDate
import java.time.ZonedDateTime

/** Чистая логика (без Android): когда срабатывает сигнал и что считать «вчерашним днём». */
object DailyReportTime {
    /** Ближайшая полночь строго после [after]. */
    fun nextMidnight(after: ZonedDateTime): ZonedDateTime =
        after.toLocalDate().plusDays(1).atStartOfDay(after.zone)

    /** Сигнал на полночь начала дня [targetDay] отчитывается за предыдущий день. */
    fun reportDayFor(targetDay: Long): Long = targetDay - 1

    /**
     * От какого момента считать следующую полночь после срабатывания.
     * Если сигнал вдруг пришёл чуть раньше полуночи, берём саму полночь, чтобы не получить повтор.
     */
    fun baseAfterFire(now: ZonedDateTime, targetDay: Long): ZonedDateTime {
        val start = LocalDate.ofEpochDay(targetDay).atStartOfDay(now.zone)
        return if (now.isBefore(start)) start else now
    }
}

data class DailyReportData(
    val day: Long,
    val total: Long,
    val count: Int,
    /** До трёх крупнейших категорий расходов за день. */
    val top: List<CategorySlice>
)

object DailyReportBuilder {
    /** Считаются только расходы с датой [day]. Доходы и переводы в сбережения не учитываются. */
    fun build(day: Long, ops: List<Operation>): DailyReportData {
        val expenses = ops.filter { it.type == FlowType.EXPENSE && it.date == day }
        return DailyReportData(
            day = day,
            total = expenses.sumOf { it.amountMinor },
            count = expenses.size,
            top = StatsCalculator.categorySlices(expenses, FlowType.EXPENSE).take(3)
        )
    }
}
