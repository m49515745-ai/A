package com.personalfinance.app.ui.operations

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.R
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.ConfirmDeleteDialog
import com.personalfinance.app.ui.common.DateField
import com.personalfinance.app.ui.common.EmptyState
import com.personalfinance.app.ui.common.ErrorDialog
import com.personalfinance.app.ui.common.OperationRow
import com.personalfinance.app.ui.common.categoryName
import com.personalfinance.app.ui.common.formatDate
import com.personalfinance.app.domain.Money

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OperationsScreen(
    vm: OperationsViewModel,
    onAdd: (FlowType) -> Unit,
    onOpen: (Operation) -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val categoriesById = remember(state.categories) { state.categories.associateBy { it.id } }
    var toDelete by remember { mutableStateOf<Operation?>(null) }
    var categoryMenu by remember { mutableStateOf(false) }
    val f = state.filter
    val visibleCategories = state.categories.filter { f.type == null || it.type == f.type }
    val filtersActive = f.type != null || f.categoryId != null || f.fromDay != null || f.toDay != null

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.tab_operations), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { onAdd(FlowType.INCOME) }) { Text("+ " + stringResource(R.string.type_income)) }
                TextButton(onClick = { onAdd(FlowType.EXPENSE) }) { Text("+ " + stringResource(R.string.type_expense)) }
            }
        }
        item {
            AppCard(Modifier.padding(vertical = 8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = f.type == null, onClick = { vm.setType(null) }, label = { Text(stringResource(R.string.type_all)) })
                    FilterChip(selected = f.type == FlowType.INCOME, onClick = { vm.setType(FlowType.INCOME) }, label = { Text(stringResource(R.string.type_income)) })
                    FilterChip(selected = f.type == FlowType.EXPENSE, onClick = { vm.setType(FlowType.EXPENSE) }, label = { Text(stringResource(R.string.type_expense)) })
                }
                FlowRow(
                    Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box {
                        OutlinedButton(onClick = { categoryMenu = true }) {
                            Text(
                                if (f.categoryId == null) stringResource(R.string.filter_category)
                                else stringResource(R.string.filter_category) + ": " + categoryName(categoriesById[f.categoryId]),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        DropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.filter_all_categories)) },
                                onClick = { vm.setCategory(null); categoryMenu = false }
                            )
                            visibleCategories.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(categoryName(c)) },
                                    onClick = { vm.setCategory(c.id); categoryMenu = false }
                                )
                            }
                        }
                    }
                    DateField(stringResource(R.string.filter_from), f.fromDay, onPicked = { vm.setFrom(it) })
                    DateField(stringResource(R.string.filter_to), f.toDay, onPicked = { vm.setTo(it) })
                }
                if (filtersActive) {
                    TextButton(onClick = { vm.resetFilters() }) { Text(stringResource(R.string.filter_reset)) }
                }
            }
        }
        if (state.items.isEmpty()) {
            item {
                EmptyState(stringResource(if (filtersActive) R.string.ops_empty_filtered else R.string.ops_empty))
            }
        } else {
            items(state.items, key = { it.id }) { op ->
                OperationRow(
                    op = op,
                    category = categoriesById[op.categoryId],
                    onClick = { onOpen(op) },
                    onDelete = { toDelete = op }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            }
        }
        item { Box(Modifier.padding(8.dp)) }
    }

    toDelete?.let { op ->
        ConfirmDeleteDialog(
            message = stringResource(
                R.string.delete_confirm_op,
                Money.withCurrency(op.amountMinor),
                categoryName(categoriesById[op.categoryId]),
                formatDate(op.date)
            ),
            onConfirm = { vm.delete(op.id); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
    ErrorDialog(vm.error, onDismiss = vm::clearError)
}
