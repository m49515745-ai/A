package com.personalfinance.app.notify

import android.content.Context

/** Настройки уведомлений хранятся на устройстве (не входят в резервную копию). */
class NotifyPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("notify_prefs", Context.MODE_PRIVATE)

    /** false до первого запуска версии с уведомлениями: тогда они включаются автоматически. */
    var initialized: Boolean
        get() = sp.getBoolean("initialized", false)
        set(v) { sp.edit().putBoolean("initialized", v).apply() }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    /** Какой день (epochDay) уже был отправлен в отчёте; -1 — неизвестно. */
    var lastReportedDay: Long
        get() = sp.getLong("lastReportedDay", -1L)
        set(v) { sp.edit().putLong("lastReportedDay", v).apply() }
}
