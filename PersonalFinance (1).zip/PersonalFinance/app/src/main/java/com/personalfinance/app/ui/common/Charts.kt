package com.personalfinance.app.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personalfinance.app.R
import com.personalfinance.app.domain.Bucket
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.CategorySlice
import com.personalfinance.app.domain.Money
import com.personalfinance.app.ui.theme.FinanceColors

/** Сгруппированные столбцы «доход / расход». Все значения берутся из переданных бакетов (то есть из БД). */
@Composable
fun BarChart(buckets: List<Bucket>, monthLabels: Boolean, modifier: Modifier = Modifier) {
    val incomeColor = FinanceColors.income
    val expenseColor = FinanceColors.expense
    val axis = MaterialTheme.colorScheme.outline
    val maxValue = (buckets.maxOfOrNull { maxOf(it.income, it.expense) } ?: 0L).coerceAtLeast(1L)

    Column(modifier) {
        val hasData = buckets.any { it.income > 0 || it.expense > 0 }
        Text(
            Money.withCurrency(if (hasData) maxValue else 0L),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val n = buckets.size
            if (n == 0) return@Canvas
            val slot = size.width / n
            val barW = (slot * 0.38f).coerceAtLeast(1f)
            drawLine(axis, Offset(0f, size.height), Offset(size.width, size.height), 2f)
            buckets.forEachIndexed { i, b ->
                val center = i * slot + slot / 2f
                val hi = if (b.income > 0) (b.income.toFloat() / maxValue * size.height).coerceAtLeast(2f) else 0f
                val he = if (b.expense > 0) (b.expense.toFloat() / maxValue * size.height).coerceAtLeast(2f) else 0f
                if (hi > 0f) drawRect(incomeColor, Offset(center - barW, size.height - hi), Size(barW, hi))
                if (he > 0f) drawRect(expenseColor, Offset(center, size.height - he), Size(barW, he))
            }
        }
        if (buckets.isNotEmpty()) {
            val fmt: (Long) -> String = if (monthLabels) ::formatMonthYear else ::formatDayMonth
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(buckets.first().startDay), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (buckets.size > 1) {
                    Text(fmt(buckets.last().startDay), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            LegendDot(incomeColor, stringResource(R.string.legend_income))
            LegendDot(expenseColor, stringResource(R.string.legend_expense))
        }
    }
}

@Composable
fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Кольцевая диаграмма по категориям + легенда с суммами, процентами и количеством операций. */
@Composable
fun CategoryBreakdown(
    slices: List<CategorySlice>,
    categories: Map<Long, Category>,
    onCategoryClick: ((CategorySlice) -> Unit)? = null
) {
    val total = slices.sumOf { it.amount }
    if (total <= 0L) {
        EmptyState(stringResource(R.string.stats_no_data))
        return
    }
    val colors = FinanceColors.palette
    Column {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(150.dp)) {
                val stroke = 26.dp.toPx()
                var start = -90f
                slices.forEachIndexed { i, s ->
                    val sweep = s.amount.toFloat() / total * 360f
                    drawArc(
                        color = colors[i % colors.size],
                        startAngle = start,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = Offset(stroke / 2, stroke / 2),
                        size = Size(size.width - stroke, size.height - stroke),
                        style = Stroke(stroke)
                    )
                    start += sweep
                }
            }
        }
        if (onCategoryClick != null) {
            Text(
                stringResource(R.string.stats_tap_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        slices.forEachIndexed { i, s ->
            Row(
                Modifier.fillMaxWidth()
                    .then(if (onCategoryClick != null) Modifier.clickable { onCategoryClick(s) } else Modifier)
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(10.dp).background(colors[i % colors.size], CircleShape))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(categoryName(categories[s.categoryId]), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        stringResource(R.string.stats_ops_count, s.count),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(Money.withCurrency(s.amount), style = MaterialTheme.typography.bodyMedium)
                    val tenths = s.amount * 1000 / total
                    Text(
                        "${tenths / 10}.${tenths % 10}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (onCategoryClick != null) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
