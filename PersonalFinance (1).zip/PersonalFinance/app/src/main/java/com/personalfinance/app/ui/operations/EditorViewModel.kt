package com.personalfinance.app.ui.operations

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.concurrent.atomic.AtomicBoolean

/** id <= 0 — новая операция. */
class EditorViewModel(
    private val repo: FinanceRepository,
    val type: FlowType,
    private val id: Long
) : ViewModel() {
    val isEdit: Boolean get() = id > 0

    var amount by mutableStateOf("")
    var categoryId by mutableStateOf<Long?>(null)
    var date by mutableLongStateOf(LocalDate.now().toEpochDay())
    var comment by mutableStateOf("")
    var amountInvalid by mutableStateOf(false)
    var done by mutableStateOf(false)
        private set
    var error by mutableStateOf<FinanceError?>(null)
        private set

    /** Защита от двойного нажатия: после первого принятого сохранения новые вызовы игнорируются. */
    private val saving = AtomicBoolean(false)

    val categories: StateFlow<List<Category>> = repo.categories
        .map { list -> list.filter { it.type == type } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        if (id > 0) {
            viewModelScope.launch {
                repo.getOperation(id)?.let { op ->
                    amount = Money.toInput(op.amountMinor)
                    categoryId = op.categoryId
                    date = op.date
                    comment = op.comment ?: ""
                } ?: run { error = FinanceError.NOT_FOUND }
            }
        }
    }

    fun clearError() { error = null }

    fun save() {
        if (!saving.compareAndSet(false, true)) return
        val minor = Money.parse(amount)
        if (minor == null) {
            amountInvalid = true
            saving.set(false)
            return
        }
        viewModelScope.launch {
            try {
                val category = categoryId
                    ?: repo.categories.first().firstOrNull { it.type == type }?.id
                    ?: throw FinanceException(FinanceError.CATEGORY_NOT_FOUND)
                repo.saveOperation(if (id > 0) id else null, type, minor, category, date, comment)
                done = true // флаг saving остаётся true: повторное сохранение невозможно
            } catch (e: FinanceException) {
                error = e.error
                saving.set(false)
            }
        }
    }
}
