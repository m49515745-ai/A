package com.personalfinance.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.ZonedDateTime

object DailyReportScheduler {
    const val ACTION_REPORT = "com.personalfinance.app.action.DAILY_REPORT"
    const val EXTRA_TARGET_DAY = "targetDay"
    private const val REQUEST_CODE = 1001

    private fun pendingIntent(context: Context, targetDay: Long): PendingIntent {
        val intent = Intent(context, DailyReportReceiver::class.java)
            .setAction(ACTION_REPORT)
            .putExtra(EXTRA_TARGET_DAY, targetDay)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Ставит сигнал на ближайшие 00:00 по местному времени (заменяет прежний). */
    fun schedule(context: Context, after: ZonedDateTime = ZonedDateTime.now()) {
        val app = context.applicationContext
        val alarmManager = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = DailyReportTime.nextMidnight(after)
        val pi = pendingIntent(app, next.toLocalDate().toEpochDay())
        val trigger = next.toInstant().toEpochMilli()
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
        try {
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    fun cancel(context: Context) {
        val app = context.applicationContext
        val alarmManager = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent(app, 0))
    }
}
