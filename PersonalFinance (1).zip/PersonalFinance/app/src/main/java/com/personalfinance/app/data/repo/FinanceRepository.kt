package com.personalfinance.app.data.repo

import androidx.room.withTransaction
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.db.CategoryEntity
import com.personalfinance.app.data.db.SavingsTransferEntity
import com.personalfinance.app.data.db.TransactionEntity
import com.personalfinance.app.data.db.toDomain
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.Dates
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FinanceTotals
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.domain.SystemCategories
import com.personalfinance.app.domain.Transfer
import com.personalfinance.app.domain.TransferDirection
import com.personalfinance.app.domain.TxFilter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/**
 * Единственная точка записи финансовых данных.
 * Баланс НЕ хранится: он всегда вычисляется из записей. Любое изменение выполняется в
 * транзакции БД; если итоговое состояние недопустимо (отрицательный баланс или
 * сбережения), транзакция откатывается и бросается FinanceException.
 */
class FinanceRepository(
    private val db: AppDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val categoryDao = db.categoryDao()
    private val txDao = db.transactionDao()
    private val savingsDao = db.savingsDao()

    // ---------- Наблюдение ----------

    val categories: Flow<List<Category>> =
        categoryDao.observeAll().map { list -> list.map { it.toDomain() } }

    val totals: Flow<FinanceTotals> = combine(
        txDao.observeSum(FlowType.INCOME.name),
        txDao.observeSum(FlowType.EXPENSE.name),
        savingsDao.observeSum(TransferDirection.TO_SAVINGS.name),
        savingsDao.observeSum(TransferDirection.FROM_SAVINGS.name)
    ) { income, expense, to, from -> FinanceTotals(income, expense, to, from) }
        .distinctUntilChanged()

    val transfers: Flow<List<Transfer>> =
        savingsDao.observeAll().map { list -> list.map { it.toDomain() } }

    fun operations(filter: TxFilter): Flow<List<Operation>> =
        txDao.observeFiltered(filter.type?.name, filter.categoryId, filter.fromDay, filter.toDay)
            .map { list -> list.map { it.toDomain() } }

    fun operationsInRange(fromDay: Long, toDay: Long): Flow<List<Operation>> =
        txDao.observeInRange(fromDay, toDay).map { list -> list.map { it.toDomain() } }

    fun recentOperations(limit: Int): Flow<List<Operation>> =
        txDao.observeRecent(limit).map { list -> list.map { it.toDomain() } }

    suspend fun getOperation(id: Long): Operation? = txDao.getById(id)?.toDomain()
    suspend fun getTransfer(id: Long): Transfer? = savingsDao.getById(id)?.toDomain()

    suspend fun currentTotals(): FinanceTotals = FinanceTotals(
        txDao.sum(FlowType.INCOME.name),
        txDao.sum(FlowType.EXPENSE.name),
        savingsDao.sum(TransferDirection.TO_SAVINGS.name),
        savingsDao.sum(TransferDirection.FROM_SAVINGS.name)
    )

    // ---------- Операции ----------

    /** id == null — создание, иначе редактирование. Возвращает id записи. */
    suspend fun saveOperation(
        id: Long?,
        type: FlowType,
        amountMinor: Long,
        categoryId: Long,
        date: Long,
        comment: String?
    ): Long {
        requireAmount(amountMinor)
        requireDate(date)
        val cleanComment = cleanComment(comment)
        return db.withTransaction {
            val category = categoryDao.getById(categoryId) ?: throw FinanceException(FinanceError.CATEGORY_NOT_FOUND)
            if (category.type != type) throw FinanceException(FinanceError.CATEGORY_MISMATCH)
            val now = clock()
            val savedId = if (id == null) {
                txDao.insert(TransactionEntity(0, type, amountMinor, categoryId, date, cleanComment, now, now))
            } else {
                val old = txDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
                txDao.update(
                    old.copy(
                        type = type, amountMinor = amountMinor, categoryId = categoryId,
                        date = date, comment = cleanComment, updatedAt = now
                    )
                )
                id
            }
            verifyState()
            savedId
        }
    }

    suspend fun deleteOperation(id: Long) {
        db.withTransaction {
            txDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
            txDao.deleteById(id)
            verifyState()
        }
    }

    // ---------- Сбережения ----------

    suspend fun saveTransfer(
        id: Long?,
        direction: TransferDirection,
        amountMinor: Long,
        date: Long,
        comment: String?
    ): Long {
        requireAmount(amountMinor)
        requireDate(date)
        val cleanComment = cleanComment(comment)
        return db.withTransaction {
            val now = clock()
            val savedId = if (id == null) {
                savingsDao.insert(SavingsTransferEntity(0, direction, amountMinor, date, cleanComment, now, now))
            } else {
                val old = savingsDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
                savingsDao.update(
                    old.copy(direction = direction, amountMinor = amountMinor, date = date, comment = cleanComment, updatedAt = now)
                )
                id
            }
            verifyState()
            savedId
        }
    }

    suspend fun deleteTransfer(id: Long) {
        db.withTransaction {
            savingsDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
            savingsDao.deleteById(id)
            verifyState()
        }
    }

    // ---------- Категории ----------

    /** Идемпотентно: повторный вызов ничего не дублирует (уникальный индекс по systemKey). */
    suspend fun ensureSystemCategories() {
        db.withTransaction {
            SystemCategories.all.forEach { (type, key) ->
                categoryDao.insertIgnore(CategoryEntity(0, type, key, null, true))
            }
        }
    }

    suspend fun addCategory(type: FlowType, name: String): Long {
        val clean = name.trim()
        if (clean.isEmpty()) throw FinanceException(FinanceError.EMPTY_NAME)
        return db.withTransaction {
            if (nameTaken(type, clean, null)) throw FinanceException(FinanceError.NAME_EXISTS)
            categoryDao.insert(CategoryEntity(0, type, null, clean.take(40), false))
        }
    }

    suspend fun renameCategory(id: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) throw FinanceException(FinanceError.EMPTY_NAME)
        db.withTransaction {
            val c = categoryDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
            if (c.isSystem) throw FinanceException(FinanceError.CATEGORY_PROTECTED)
            if (nameTaken(c.type, clean, id)) throw FinanceException(FinanceError.NAME_EXISTS)
            categoryDao.update(c.copy(customName = clean.take(40)))
        }
    }

    /** Системные категории и категории, к которым привязаны операции, удалить нельзя. */
    suspend fun deleteCategory(id: Long) {
        db.withTransaction {
            val c = categoryDao.getById(id) ?: throw FinanceException(FinanceError.NOT_FOUND)
            if (c.isSystem) throw FinanceException(FinanceError.CATEGORY_PROTECTED)
            if (categoryDao.usageCount(id) > 0) throw FinanceException(FinanceError.CATEGORY_IN_USE)
            categoryDao.deleteById(id)
        }
    }

    // ---------- Внутреннее ----------

    private suspend fun nameTaken(type: FlowType, name: String, exceptId: Long?): Boolean =
        categoryDao.getAll().any {
            !it.isSystem && it.type == type && it.id != exceptId &&
                it.customName.equals(name, ignoreCase = true)
        }

    private suspend fun verifyState() {
        currentTotals().error()?.let { throw FinanceException(it) }
    }

    private fun requireAmount(amountMinor: Long) {
        if (amountMinor <= 0 || amountMinor > Money.MAX_MINOR) throw FinanceException(FinanceError.INVALID_AMOUNT)
    }

    private fun requireDate(date: Long) {
        if (!Dates.isValid(date)) throw FinanceException(FinanceError.INVALID_DATE)
    }

    private fun cleanComment(comment: String?): String? = comment?.trim()?.takeIf { it.isNotEmpty() }?.take(500)
}
