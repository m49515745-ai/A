package com.personalfinance.app.data.backup

import androidx.room.withTransaction
import com.personalfinance.app.data.db.AppDatabase
import com.personalfinance.app.data.db.AppSettingsEntity
import com.personalfinance.app.data.db.CategoryEntity
import com.personalfinance.app.data.db.SavingsTransferEntity
import com.personalfinance.app.data.db.TransactionEntity
import com.personalfinance.app.data.repo.SettingsRepository
import com.personalfinance.app.domain.Dates
import com.personalfinance.app.domain.FinanceTotals
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.SystemCategories
import com.personalfinance.app.domain.TransferDirection
import org.json.JSONArray
import org.json.JSONObject

enum class BackupError { CORRUPTED, UNSUPPORTED_VERSION, INVALID_DATA, INCONSISTENT, RESTORE_FAILED }

class BackupException(val error: BackupError) : Exception(error.name)

data class BackupData(
    val categories: List<CategoryEntity>,
    val transactions: List<TransactionEntity>,
    val transfers: List<SavingsTransferEntity>,
    val language: String
)

/**
 * Формат резервной копии (JSON, версия 1):
 * { "format": "PersonalFinanceBackup", "version": 1, "exportedAt": <мс>, "currency": "TMT",
 *   "amountUnit": "tenge (1/100 TMT)", "language": "ru",
 *   "categories": [...], "transactions": [...], "savingsTransfers": [...] }
 * Суммы — целые числа в тенге, даты — epochDay.
 */
class BackupManager(
    private val db: AppDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    suspend fun exportJson(): String {
        val data = db.withTransaction {
            BackupData(
                db.categoryDao().getAll(),
                db.transactionDao().getAll(),
                db.savingsDao().getAll(),
                db.settingsDao().get()?.language ?: SettingsRepository.DEFAULT_LANGUAGE
            )
        }
        val root = JSONObject()
        root.put("format", FORMAT)
        root.put("version", VERSION)
        root.put("exportedAt", clock())
        root.put("currency", Money.CURRENCY)
        root.put("amountUnit", "tenge (1/100 TMT)")
        root.put("language", data.language)
        root.put("categories", JSONArray().also { arr ->
            data.categories.forEach { c ->
                arr.put(JSONObject().apply {
                    put("id", c.id); put("type", c.type.name); put("isSystem", c.isSystem)
                    put("systemKey", c.systemKey ?: JSONObject.NULL)
                    put("customName", c.customName ?: JSONObject.NULL)
                })
            }
        })
        root.put("transactions", JSONArray().also { arr ->
            data.transactions.forEach { t ->
                arr.put(JSONObject().apply {
                    put("id", t.id); put("type", t.type.name); put("amountMinor", t.amountMinor)
                    put("categoryId", t.categoryId); put("date", t.date)
                    put("comment", t.comment ?: JSONObject.NULL)
                    put("createdAt", t.createdAt); put("updatedAt", t.updatedAt)
                })
            }
        })
        root.put("savingsTransfers", JSONArray().also { arr ->
            data.transfers.forEach { t ->
                arr.put(JSONObject().apply {
                    put("id", t.id); put("direction", t.direction.name); put("amountMinor", t.amountMinor)
                    put("date", t.date); put("comment", t.comment ?: JSONObject.NULL)
                    put("createdAt", t.createdAt); put("updatedAt", t.updatedAt)
                })
            }
        })
        return root.toString(2)
    }

    /** Полная проверка файла без каких-либо изменений в базе. */
    fun parse(json: String): BackupData {
        try {
            val root = JSONObject(json.removePrefix("\uFEFF"))
            if (root.str("format") != FORMAT) throw BackupException(BackupError.INVALID_DATA)
            val version = root.long("version")
            if (version != VERSION.toLong()) throw BackupException(BackupError.UNSUPPORTED_VERSION)

            val language = root.optStr("language") ?: SettingsRepository.DEFAULT_LANGUAGE
            if (language !in SettingsRepository.SUPPORTED_LANGUAGES) throw BackupException(BackupError.INVALID_DATA)

            val categories = root.getJSONArray("categories").objects().map { o ->
                val isSystem = o.bool("isSystem")
                val type = o.enum<FlowType>("type")
                val key = o.optStr("systemKey")
                val name = o.optStr("customName")?.trim()
                val id = o.long("id")
                if (id <= 0) bad()
                if (isSystem) {
                    if (key == null || SystemCategories.typeOf(key) != type) bad()
                } else {
                    if (key != null || name.isNullOrEmpty() || name.length > 40) bad()
                }
                CategoryEntity(id, type, key, if (isSystem) null else name, isSystem)
            }
            if (categories.map { it.id }.toSet().size != categories.size) bad()
            val keys = categories.mapNotNull { it.systemKey }
            if (keys.toSet().size != keys.size) bad()
            val catById = categories.associateBy { it.id }

            val transactions = root.getJSONArray("transactions").objects().map { o ->
                val type = o.enum<FlowType>("type")
                val cat = catById[o.long("categoryId")] ?: bad()
                if (cat.type != type) bad()
                val amount = o.long("amountMinor")
                val date = o.long("date")
                if (amount <= 0 || amount > Money.MAX_MINOR || !Dates.isValid(date) || o.long("id") <= 0) bad()
                TransactionEntity(
                    o.long("id"), type, amount, cat.id, date, o.optStr("comment")?.take(500),
                    o.long("createdAt"), o.long("updatedAt")
                )
            }
            if (transactions.map { it.id }.toSet().size != transactions.size) bad()

            val transfers = root.getJSONArray("savingsTransfers").objects().map { o ->
                val amount = o.long("amountMinor")
                val date = o.long("date")
                if (amount <= 0 || amount > Money.MAX_MINOR || !Dates.isValid(date) || o.long("id") <= 0) bad()
                SavingsTransferEntity(
                    o.long("id"), o.enum<TransferDirection>("direction"), amount, date,
                    o.optStr("comment")?.take(500), o.long("createdAt"), o.long("updatedAt")
                )
            }
            if (transfers.map { it.id }.toSet().size != transfers.size) bad()

            val totals = FinanceTotals(
                transactions.filter { it.type == FlowType.INCOME }.sumOf { it.amountMinor },
                transactions.filter { it.type == FlowType.EXPENSE }.sumOf { it.amountMinor },
                transfers.filter { it.direction == TransferDirection.TO_SAVINGS }.sumOf { it.amountMinor },
                transfers.filter { it.direction == TransferDirection.FROM_SAVINGS }.sumOf { it.amountMinor }
            )
            if (totals.error() != null) throw BackupException(BackupError.INCONSISTENT)

            return BackupData(categories, transactions, transfers, language)
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException(BackupError.CORRUPTED)
        }
    }

    /**
     * Заменяет все данные содержимым копии одной транзакцией БД.
     * При любой ошибке транзакция откатывается и текущая база остаётся нетронутой.
     * Повторный импорт того же файла даёт то же самое состояние (замена, не добавление).
     */
    suspend fun restore(data: BackupData) {
        try {
            db.withTransaction {
                db.transactionDao().deleteAll()
                db.savingsDao().deleteAll()
                db.categoryDao().deleteAll()
                db.categoryDao().insertAll(data.categories)
                SystemCategories.all.forEach { (type, key) ->
                    db.categoryDao().insertIgnore(CategoryEntity(0, type, key, null, true))
                }
                db.transactionDao().insertAll(data.transactions)
                db.savingsDao().insertAll(data.transfers)
                db.settingsDao().upsert(AppSettingsEntity(1, data.language))
            }
        } catch (e: Exception) {
            throw BackupException(BackupError.RESTORE_FAILED)
        }
    }

    companion object {
        const val FORMAT = "PersonalFinanceBackup"
        const val VERSION = 1
    }
}

private fun bad(): Nothing = throw BackupException(BackupError.INVALID_DATA)

private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

private fun JSONObject.long(key: String): Long {
    val v = get(key)
    return when (v) {
        is Int -> v.toLong()
        is Long -> v
        else -> bad()
    }
}

private fun JSONObject.str(key: String): String = get(key) as? String ?: bad()

private fun JSONObject.bool(key: String): Boolean = get(key) as? Boolean ?: bad()

private fun JSONObject.optStr(key: String): String? {
    if (!has(key) || isNull(key)) return null
    return get(key) as? String ?: bad()
}

private inline fun <reified E : Enum<E>> JSONObject.enum(key: String): E =
    enumValues<E>().firstOrNull { it.name == str(key) } ?: bad()
