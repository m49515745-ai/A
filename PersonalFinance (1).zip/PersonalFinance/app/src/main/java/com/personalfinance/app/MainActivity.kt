package com.personalfinance.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import com.personalfinance.app.notify.DailyReportJob
import com.personalfinance.app.notify.DailyReportScheduler
import com.personalfinance.app.notify.NotifyPrefs
import kotlinx.coroutines.Dispatchers
import java.time.LocalDate
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.personalfinance.app.ui.nav.AppRoot
import com.personalfinance.app.ui.theme.PersonalFinanceTheme
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var createdLanguage: String = "ru"

    // Ответ пользователя на запрос разрешения показывать уведомления (Android 13+).
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun attachBaseContext(newBase: Context) {
        val container = AppContainer.get(newBase)
        val lang = runBlocking { container.settings.getLanguage() }
        createdLanguage = lang
        val locale = Locale.forLanguageTag(lang)
        Locale.setDefault(locale)
        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        val container = AppContainer.get(this)

        // Ежедневный отчёт: при первом запуске этой версии включается сам (можно выключить в настройках).
        val notifyPrefs = NotifyPrefs(this)
        if (!notifyPrefs.initialized) {
            notifyPrefs.initialized = true
            notifyPrefs.enabled = true
            notifyPrefs.lastReportedDay = LocalDate.now().toEpochDay() - 1
            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (notifyPrefs.enabled) {
            DailyReportScheduler.schedule(this)
            lifecycleScope.launch(Dispatchers.IO) { DailyReportJob.catchUp(this@MainActivity) }
        }

        // Смена языка (в настройках или при импорте копии) пересоздаёт экран с новым языком.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                container.settings.language.collect { lang ->
                    if (lang != createdLanguage) recreate()
                }
            }
        }

        setContent {
            PersonalFinanceTheme {
                AppRoot(container)
            }
        }
    }
}
