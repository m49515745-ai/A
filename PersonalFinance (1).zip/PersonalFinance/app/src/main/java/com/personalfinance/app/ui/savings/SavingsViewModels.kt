package com.personalfinance.app.ui.savings

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalfinance.app.data.repo.FinanceRepository
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FinanceException
import com.personalfinance.app.domain.FinanceTotals
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Transfer
import com.personalfinance.app.domain.TransferDirection
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.concurrent.atomic.AtomicBoolean

data class SavingsState(
    val totals: FinanceTotals = FinanceTotals(0, 0, 0, 0),
    val transfers: List<Transfer> = emptyList()
)

class SavingsViewModel(private val repo: FinanceRepository) : ViewModel() {
    val state: StateFlow<SavingsState> = combine(repo.totals, repo.transfers) { t, list -> SavingsState(t, list) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SavingsState())

    var error by mutableStateOf<FinanceError?>(null)
        private set

    fun clearError() { error = null }

    fun delete(id: Long) {
        viewModelScope.launch {
            try {
                repo.deleteTransfer(id)
            } catch (e: FinanceException) {
                error = e.error
            }
        }
    }
}

/** id <= 0 — новый перевод. */
class TransferEditorViewModel(
    private val repo: FinanceRepository,
    initialDirection: TransferDirection,
    private val id: Long
) : ViewModel() {
    val isEdit: Boolean get() = id > 0

    var direction by mutableStateOf(initialDirection)
    var amount by mutableStateOf("")
    var date by mutableLongStateOf(LocalDate.now().toEpochDay())
    var comment by mutableStateOf("")
    var amountInvalid by mutableStateOf(false)
    var done by mutableStateOf(false)
        private set
    var error by mutableStateOf<FinanceError?>(null)
        private set

    val totals: StateFlow<FinanceTotals> = repo.totals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FinanceTotals(0, 0, 0, 0))

    private val saving = AtomicBoolean(false)

    init {
        if (id > 0) {
            viewModelScope.launch {
                repo.getTransfer(id)?.let { t ->
                    direction = t.direction
                    amount = Money.toInput(t.amountMinor)
                    date = t.date
                    comment = t.comment ?: ""
                } ?: run { error = FinanceError.NOT_FOUND }
            }
        }
    }

    fun clearError() { error = null }

    fun save() {
        if (!saving.compareAndSet(false, true)) return
        val minor = Money.parse(amount)
        if (minor == null) {
            amountInvalid = true
            saving.set(false)
            return
        }
        viewModelScope.launch {
            try {
                repo.saveTransfer(if (id > 0) id else null, direction, minor, date, comment)
                done = true
            } catch (e: FinanceException) {
                error = e.error
                saving.set(false)
            }
        }
    }
}
