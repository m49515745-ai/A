package com.personalfinance.app.ui.common

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personalfinance.app.R
import com.personalfinance.app.domain.Category
import com.personalfinance.app.domain.Dates
import com.personalfinance.app.domain.FinanceError
import com.personalfinance.app.domain.FlowType
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Operation
import com.personalfinance.app.ui.theme.FinanceColors
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale

fun formatDate(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return String.format(Locale.ROOT, "%02d.%02d.%04d", d.dayOfMonth, d.monthValue, d.year)
}

fun formatDayMonth(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return String.format(Locale.ROOT, "%02d.%02d", d.dayOfMonth, d.monthValue)
}

fun formatMonthYear(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return String.format(Locale.ROOT, "%02d.%04d", d.monthValue, d.year)
}

private val systemCategoryRes: Map<String, Int> = mapOf(
    "clothes" to R.string.cat_clothes,
    "mom" to R.string.cat_mom,
    "other_income" to R.string.cat_other_income,
    "food" to R.string.cat_food,
    "taxi" to R.string.cat_taxi,
    "drinks" to R.string.cat_drinks,
    "debts" to R.string.cat_debts,
    "ads" to R.string.cat_ads,
    "donation" to R.string.cat_donation,
    "groceries" to R.string.cat_groceries,
    "other" to R.string.cat_other
)

/** То же, что categoryName, но без Compose: для уведомлений. */
fun categoryLabel(context: Context, c: Category?): String {
    if (c == null) return context.getString(R.string.cat_unknown)
    if (c.isSystem) {
        val res = systemCategoryRes[c.systemKey]
        if (res != null) return context.getString(res)
    }
    return c.customName ?: context.getString(R.string.cat_unknown)
}

/** Системные категории переводятся по ключу; пользовательские показываются как введены. */
@Composable
fun categoryName(c: Category?): String {
    if (c == null) return stringResource(R.string.cat_unknown)
    if (c.isSystem) {
        val res = systemCategoryRes[c.systemKey]
        if (res != null) return stringResource(res)
    }
    return c.customName ?: stringResource(R.string.cat_unknown)
}

@StringRes
fun errorRes(e: FinanceError): Int = when (e) {
    FinanceError.INSUFFICIENT_BALANCE -> R.string.err_insufficient_balance
    FinanceError.INSUFFICIENT_SAVINGS -> R.string.err_insufficient_savings
    FinanceError.INVALID_AMOUNT -> R.string.err_invalid_amount
    FinanceError.INVALID_DATE -> R.string.err_invalid_date
    FinanceError.CATEGORY_MISMATCH -> R.string.err_category_mismatch
    FinanceError.CATEGORY_NOT_FOUND -> R.string.err_category_not_found
    FinanceError.NOT_FOUND -> R.string.err_not_found
    FinanceError.CATEGORY_IN_USE -> R.string.err_category_in_use
    FinanceError.CATEGORY_PROTECTED -> R.string.err_category_protected
    FinanceError.EMPTY_NAME -> R.string.err_empty_name
    FinanceError.NAME_EXISTS -> R.string.err_name_exists
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
            }
        }
        Text(title, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
    }
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 8.dp)
    )
}

@Composable
fun ErrorDialog(error: FinanceError?, onDismiss: () -> Unit) {
    if (error == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.err_title)) },
        text = { Text(stringResource(errorRes(error))) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) } }
    )
}

@Composable
fun ConfirmDeleteDialog(message: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.delete_title)) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerHost(initialDay: Long, onDismiss: () -> Unit, onPicked: (Long) -> Unit) {
    val state = rememberDatePickerState(
        initialSelectedDateMillis = LocalDate.ofEpochDay(initialDay).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(),
        yearRange = 2000..2100
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val ms = state.selectedDateMillis
                if (ms != null) {
                    val day = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
                    if (Dates.isValid(day)) onPicked(day)
                }
                onDismiss()
            }) { Text(stringResource(R.string.action_ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    ) {
        DatePicker(state = state)
    }
}

/** Кнопка-поле выбора даты. */
@Composable
fun DateField(label: String, epochDay: Long?, onPicked: (Long) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, modifier = modifier) {
        Text(
            if (epochDay == null) label else "$label: ${formatDate(epochDay)}",
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
    if (open) {
        DatePickerHost(
            initialDay = epochDay ?: LocalDate.now().toEpochDay(),
            onDismiss = { open = false },
            onPicked = onPicked
        )
    }
}

/** Строка операции в списках. */
@Composable
fun OperationRow(
    op: Operation,
    category: Category?,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val isIncome = op.type == FlowType.INCOME
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(categoryName(category), style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = if (op.comment.isNullOrBlank()) formatDate(op.date) else "${formatDate(op.date)} · ${op.comment}"
            Text(
                sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            (if (isIncome) "+" else "−") + Money.withCurrency(op.amountMinor),
            style = MaterialTheme.typography.titleMedium,
            color = if (isIncome) FinanceColors.income else FinanceColors.expense
        )
        if (onDelete != null) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete), modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun MoneyLine(label: String, minor: Long, color: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(Money.withCurrency(minor), style = MaterialTheme.typography.titleMedium, color = color)
    }
}
