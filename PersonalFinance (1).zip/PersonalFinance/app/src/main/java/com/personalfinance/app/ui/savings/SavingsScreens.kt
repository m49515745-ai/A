package com.personalfinance.app.ui.savings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personalfinance.app.R
import com.personalfinance.app.domain.Money
import com.personalfinance.app.domain.Transfer
import com.personalfinance.app.domain.TransferDirection
import com.personalfinance.app.ui.common.AppCard
import com.personalfinance.app.ui.common.ConfirmDeleteDialog
import com.personalfinance.app.ui.common.DateField
import com.personalfinance.app.ui.common.EmptyState
import com.personalfinance.app.ui.common.ErrorDialog
import com.personalfinance.app.ui.common.MoneyLine
import com.personalfinance.app.ui.common.ScreenHeader
import com.personalfinance.app.ui.common.formatDate
import com.personalfinance.app.ui.theme.FinanceColors

@Composable
fun SavingsScreen(
    vm: SavingsViewModel,
    onNewTransfer: (TransferDirection) -> Unit,
    onOpenTransfer: (Transfer) -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<Transfer?>(null) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.tab_savings), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp)) }
        item {
            AppCard {
                Text(stringResource(R.string.savings_balance), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(Money.withCurrency(state.totals.savings), style = MaterialTheme.typography.headlineLarge, color = FinanceColors.savings)
                Column(Modifier.padding(top = 12.dp)) {
                    MoneyLine(stringResource(R.string.savings_available), state.totals.available)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { onNewTransfer(TransferDirection.TO_SAVINGS) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.savings_to))
                }
                OutlinedButton(onClick = { onNewTransfer(TransferDirection.FROM_SAVINGS) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.savings_from))
                }
            }
        }
        item { Text(stringResource(R.string.savings_history), style = MaterialTheme.typography.titleMedium) }
        if (state.transfers.isEmpty()) {
            item { EmptyState(stringResource(R.string.savings_empty)) }
        } else {
            items(state.transfers, key = { it.id }) { t ->
                val toSavings = t.direction == TransferDirection.TO_SAVINGS
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenTransfer(t) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(if (toSavings) R.string.transfer_to else R.string.transfer_from), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val sub = if (t.comment.isNullOrBlank()) formatDate(t.date) else "${formatDate(t.date)} · ${t.comment}"
                        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        (if (toSavings) "+" else "−") + Money.withCurrency(t.amountMinor),
                        style = MaterialTheme.typography.titleMedium,
                        color = FinanceColors.savings
                    )
                    IconButton(onClick = { toDelete = t }) {
                        Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete), modifier = Modifier.size(20.dp))
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            }
        }
        item { Spacer(Modifier.padding(4.dp)) }
    }

    toDelete?.let { t ->
        ConfirmDeleteDialog(
            message = stringResource(R.string.delete_confirm_transfer, Money.withCurrency(t.amountMinor), formatDate(t.date)),
            onConfirm = { vm.delete(t.id); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
    ErrorDialog(vm.error, onDismiss = vm::clearError)
}

@Composable
fun TransferEditorScreen(vm: TransferEditorViewModel, onBack: () -> Unit) {
    val totals by vm.totals.collectAsStateWithLifecycle()
    LaunchedEffect(vm.done) { if (vm.done) onBack() }

    Column(
        Modifier.imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(stringResource(if (vm.isEdit) R.string.transfer_edit else R.string.transfer_new), onBack)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = vm.direction == TransferDirection.TO_SAVINGS,
                onClick = { vm.direction = TransferDirection.TO_SAVINGS },
                label = { Text(stringResource(R.string.transfer_to)) }
            )
            FilterChip(
                selected = vm.direction == TransferDirection.FROM_SAVINGS,
                onClick = { vm.direction = TransferDirection.FROM_SAVINGS },
                label = { Text(stringResource(R.string.transfer_from)) }
            )
        }

        AppCard {
            MoneyLine(stringResource(R.string.savings_available), totals.available)
            MoneyLine(stringResource(R.string.savings_balance), totals.savings, FinanceColors.savings)
        }

        OutlinedTextField(
            value = vm.amount,
            onValueChange = { v ->
                if (v.length <= 12 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                    vm.amount = v
                    vm.amountInvalid = false
                }
            },
            label = { Text(stringResource(R.string.field_amount) + " (TMT)") },
            isError = vm.amountInvalid,
            supportingText = if (vm.amountInvalid) ({ Text(stringResource(R.string.err_amount_invalid)) }) else null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        DateField(stringResource(R.string.field_date), vm.date, onPicked = { vm.date = it }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = vm.comment,
            onValueChange = { if (it.length <= 500) vm.comment = it },
            label = { Text(stringResource(R.string.field_comment)) },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = vm::save, enabled = !vm.done, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Text(stringResource(R.string.action_save))
        }
    }
    ErrorDialog(vm.error, onDismiss = vm::clearError)
}
